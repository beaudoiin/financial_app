﻿namespace Assignment1 {
    public enum TransactionCatagory {
        Income,
        Housing,
        Groceries,
        Transportation,
        Utilities,
        Restaurants,
        Insurance,
        Debt,
        Entertainment,
        Healthcare,
        Transfers,
        Fees,
        Other
    }

    public class Transaction {
        public DateOnly Date {
            get; set;
        }
        public TransactionCatagory Catagory {
            get; set;
        }

        public decimal Amount {

            get; set;
        }
        public string Description {
            get; set;
        }
        public Transaction( DateOnly Date, decimal amount, string Description, TransactionCatagory category = 0 ) {

            this.Date = Date;
            Amount = Math.Round( amount, 2 );

            this.Description = Description;
            this.Catagory = category;
        }
    }

}