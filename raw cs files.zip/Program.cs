﻿using ClosedXML.Excel;
using static Assignment1.xmlMethods;


namespace Assignment1 {


    public enum MessageEnum {

        //Instructions
        SystemInstructionsAnyKey,
        SystemMenuBadInput,
        SystemInstructionsAbort,
        SystemInstructionsInputIncomeAmount,
        SystemInstructionsInputTransDescritption,
        SystemInstructionsEnterDate,
        SystemMenuBadDate,
        SystemMenuDateFormat,
        SystemEmptyOrSpaces,
        PressAnyKeyToContinue,

        //warning
        SystemMenuBadAmount,

        //labels
        LabelExit,
        LabelEnter,
        LabelPress,
        LabelOr,
        LabelStarting,
        LabelDate,
        LabelAmount,
        LabelDescription,
        LabelAddIncomeTransaction,
        LabelCategory,

        //General options
        Menu_Return,

        //Menu uoptions
        MainMenu_Label,
        MainMenu_TransactionManagement,
        MainMenu_BudgetTools,
        MainMenu_ReportsAndSummary,

        //Transaction management submenu
        TransMgnt_AddIncomeTransaction,
        TransMgnt_AddExpenseTransaction,
        TransMgnt_ViewAllTransactions,
        TransMgnt_SearchTransactions,
        TransMgnt_Return,
        TransMgnt_TransactionAdded,

        //Budget Tools SubMenu 
        BudgetTools_SetMonlyBudget,
        BudgetTools_UpdateBudgetCateg,
        BudgetTools_CheckRemainBudget,
        BudgetTools_Warning80PercentOverBudget,

        //Reports & Summary SubMenu
        ReportAndSum_TotalIncome,
        ReportAndSum_TotalExpense,
        BudgetTools_CurrentBalance,
        ReportAndSum_MonthlySummary,
        ReportAndSum_HighestExpenseCategory

    }
    public enum DateFormatEnum {
        NumberMonth,
        ShortMonth,
        LONGMonth
    }
    /// <summary>
    /// Enum for pointing to colors based on groups in the dictionary colorByGroup.
    /// </summary>
    public enum ColorGroup {
        Default,
        SystemExit,
        SystemError,
        SystemInstructions,
        SystemInstructionsAnyKey,
        MenuHeadings,
        MenuItems,
        Success,
        Header,
        InputStyleA
    }
    public enum ScrollType {
        Pager,
        Scroller,
        Both
    }
    public enum SearchType {
        DateRange,
        PriceRange,
        Category
    }

    class Program {


        #region ///Date Formatting
        //this is for implementing user allowing to change the way the dates are formated for printing. Checks the length for column spacing.

        //uses a tuple to store the date format and max length expected on screen
        static private Dictionary<DateFormatEnum, Tuple<string, int>> dateFormatDictionary = new() {
            {DateFormatEnum.NumberMonth, new Tuple<string, int>("dd/MM/yyyy", 10)},
            {DateFormatEnum.ShortMonth, new Tuple<string, int>( "dd/MMM/yyyy", 11)},
            {DateFormatEnum.LONGMonth, new Tuple<string, int>("dd/MMMM/yyyy", 17)}
        };
        //Input is for typing in using just numbers, and output is for how it will be printed onto the screen.
        public static Tuple<string, int> dateFormatInput = dateFormatDictionary [ DateFormatEnum.NumberMonth ];
        public static Tuple<string, int> dateFormatOut = dateFormatDictionary [ DateFormatEnum.ShortMonth ];
        #endregion
        private static List<Transaction> Transactions = new();
        private static Dictionary<TransactionCatagory, decimal> BudgetCategories = new();

        const string xmlfile = @"C:\Users\beaud\source\repos\Assignment1\Assignment1\language\lang.xml";

        //Add as defualt hardcoded incase an element is missign from the xml dictionary or the dictionary cant be loaded.
        //Ensure at deployment these elements match the default english in the xml.
        public static Dictionary<MessageEnum, string> defaultEnglishMessages = new() {
    // instructions
    { MessageEnum.SystemInstructionsAnyKey, "Press any key to Acknowledge" },
    { MessageEnum.SystemMenuBadInput, "Bad Input! Try again!" },
    { MessageEnum.SystemMenuBadAmount, "Amount must be greater than zero and cannot be blank." },
    { MessageEnum.SystemInstructionsAbort, "(Type exit to abort)" },
    { MessageEnum.SystemInstructionsInputIncomeAmount, "Please enter an income Amount as a positive number" },
    { MessageEnum.SystemInstructionsInputTransDescritption, "Please enter a description of the transaction" },
    { MessageEnum.SystemInstructionsEnterDate, "Please enter the transaction date in the following format:" },
    { MessageEnum.SystemMenuBadDate, "Please use the proper date convention:" },
    { MessageEnum.SystemMenuDateFormat, "dd/MM/yyyy" },
    { MessageEnum.SystemEmptyOrSpaces, "Can't be empty or spaces only!" },
    { MessageEnum.PressAnyKeyToContinue, "Press Any Key To Continue" },

    // labels
    { MessageEnum.LabelExit, "exit" },
    { MessageEnum.LabelEnter, "Enter" },
    { MessageEnum.LabelOr, "or" },
    { MessageEnum.LabelStarting, "Starting" },
    { MessageEnum.LabelDate, "Date" },
    { MessageEnum.LabelAmount, "Amount" },
    { MessageEnum.LabelDescription, "Description" },
    { MessageEnum.LabelAddIncomeTransaction, "Add Income Transaction" },
    { MessageEnum.LabelCategory, "Category" },
    { MessageEnum.LabelPress, "Press" },

    // general options
    { MessageEnum.Menu_Return, "Return to main menu" },

    // main menu
    { MessageEnum.MainMenu_Label, "Main menu" },
    { MessageEnum.MainMenu_TransactionManagement, "Transaction management" },
    { MessageEnum.MainMenu_BudgetTools, "Budget Tools" },
    { MessageEnum.MainMenu_ReportsAndSummary, "Reports And Summary" },

    // transaction management submenu
    { MessageEnum.TransMgnt_AddIncomeTransaction, "Add income transaction" },
    { MessageEnum.TransMgnt_Return, "Returning to transactional management" },
    { MessageEnum.TransMgnt_AddExpenseTransaction, "Add expense transaction" },
    { MessageEnum.TransMgnt_ViewAllTransactions, "View all transactions" },
    { MessageEnum.TransMgnt_SearchTransactions, "Search for a transaction" },
    { MessageEnum.TransMgnt_TransactionAdded, "Congratulations, Transaction added!" },

    // budget tools submenu
    { MessageEnum.BudgetTools_SetMonlyBudget, "Set monthly budget" },
    { MessageEnum.BudgetTools_UpdateBudgetCateg, "Update budget category" },
    { MessageEnum.BudgetTools_CheckRemainBudget, "Check remaining budget" },
    { MessageEnum.BudgetTools_Warning80PercentOverBudget, "Warning! You are more then 80Percent over your budget" },

    // reports & summary submenu
    { MessageEnum.ReportAndSum_TotalIncome, "Total income" },
    { MessageEnum.ReportAndSum_TotalExpense, "Total expense" },
    { MessageEnum.BudgetTools_CurrentBalance, "Check remaining budget" },
    { MessageEnum.ReportAndSum_MonthlySummary, "Monthly summary" },
    { MessageEnum.ReportAndSum_HighestExpenseCategory, "Highest expense category" }
};

        public static bool optionsClearAfterAwknoledge = true;
        /// <summary>
        /// Dictionary for grouped colors. ColorGroup enum As Key and value is an 2 length array, Foreground ConsoleColor, and Background ConsoleColor.
        /// </summary>
        public static Dictionary<ColorGroup, ConsoleColor [ ]> colorByGroup = new() {
            {ColorGroup.Default, [ConsoleColor.White, ConsoleColor.Black ] },
            {ColorGroup.SystemExit, [ConsoleColor.Red, ConsoleColor.Black ] },
            {ColorGroup.SystemError, [ConsoleColor.Red, ConsoleColor.White ] },
            {ColorGroup.SystemInstructions, [ConsoleColor.Cyan, ConsoleColor.Black ] },
            {ColorGroup.SystemInstructionsAnyKey, [ConsoleColor.Gray, ConsoleColor.Black ] },
            {ColorGroup.MenuHeadings, [ConsoleColor.Cyan, ConsoleColor.Black ] },
            {ColorGroup.MenuItems, [ConsoleColor.Green, ConsoleColor.Black ] },
            {ColorGroup.Success, [ConsoleColor.Black, ConsoleColor.Yellow ] },
            {ColorGroup.Header, [ConsoleColor.Yellow, ConsoleColor.Black ] },
            {ColorGroup.InputStyleA, [ConsoleColor.Black, ConsoleColor.White ] }

        };
        public static ConsoleColor [ ] MenuHeadings = colorByGroup [ ColorGroup.MenuHeadings ];
        public static ConsoleColor [ ] MenuItemColor = colorByGroup [ ColorGroup.MenuItems ];

        /// <summary>
        ///Provides index keys for outputMessage Dictionary. Assisst in outputting the proper WriteLine messages.
        ///Ensure these match the keys in xml for each language.
        /// </summary>

        enum IncomeOrExpense {
            Income,
            Expense
        }
        //Creates an empty outputMessages 
        public static Dictionary<MessageEnum, string> outputMessage = new();

        /// <summary>
        /// ISO 639 language code to specify language to load from xml.
        /// </summary>
        public static string language = "en"; //why does this have to be static to be used in XDocument?

        public static int transactionCategoryLongestSize;
        static IXLWorksheet? ws;
        static XLWorkbook? workbook;
        static void Main( string [ ] args ) {




            Console.ForegroundColor = colorByGroup [ ColorGroup.Default ] [ 0 ];
            Console.BackgroundColor = colorByGroup [ ColorGroup.Default ] [ 1 ];
            Console.Clear();
            // Housing = 600
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 1 ), 200m, "Housing A", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 5 ), 200m, "Housing B", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 9 ), 200m, "Housing C", TransactionCatagory.Housing ) );

            // Groceries = 600
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 2 ), 300m, "Groceries A", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 6 ), 200m, "Groceries B", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 10 ), 100m, "Groceries C", TransactionCatagory.Groceries ) );

            // Insurance = 600
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 3 ), 250m, "Insurance A", TransactionCatagory.Insurance ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 7 ), 200m, "Insurance B", TransactionCatagory.Insurance ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 11 ), 150m, "Insurance C", TransactionCatagory.Insurance ) );

            // Debt = 600
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 4 ), 400m, "Debt A", TransactionCatagory.Debt ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 8 ), 100m, "Debt B", TransactionCatagory.Debt ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 12 ), 100m, "Debt C", TransactionCatagory.Debt ) );

            // Lower totals (control group)

            // Transportation = 300
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 13 ), 100m, "Transport A", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 14 ), 100m, "Transport B", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 15 ), 100m, "Transport C", TransactionCatagory.Transportation ) );

            // Entertainment = 150
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 16 ), 50m, "Entertainment A", TransactionCatagory.Entertainment ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 17 ), 50m, "Entertainment B", TransactionCatagory.Entertainment ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 4, 18 ), 50m, "Entertainment C", TransactionCatagory.Entertainment ) );
            // Lower totals (control group)

            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 2 ), 1450.75m, "Rent Payment", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 3 ), 182.34m, "Weekly Groceries", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 6 ), 120.99m, "Electric Bill", TransactionCatagory.Utilities ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 8 ), 58.20m, "Dinner Out", TransactionCatagory.Restaurants ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 12 ), 350.00m, "Credit Card Payment", TransactionCatagory.Debt ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 12 ), 1000.00m, "cat food", TransactionCatagory.Other ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 14 ), 24.99m, "Streaming Subscription", TransactionCatagory.Entertainment ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 15 ), 95.57357357m, "Pharmacy Purchase", TransactionCatagory.Healthcare ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 1, 20 ), 15.00m, "Bank Service Fee", TransactionCatagory.Fees ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 2 ), 1450.75m, "Rent Payment", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 7 ), 63.15m, "Fuel", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 9 ), 134.22m, "Water & Electric", TransactionCatagory.Utilities ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 12 ), 89.75m, "Restaurant Night", TransactionCatagory.Restaurants ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 16 ), 225.00m, "Insurance Installment", TransactionCatagory.Insurance ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 18 ), 400.00m, "Loan Repayment", TransactionCatagory.Debt ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 21 ), 49.999999m, "Movie + Snacks", TransactionCatagory.Entertainment ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 23 ), 120.577535m, "Doctor Visit", TransactionCatagory.Healthcare ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 25 ), 750.00m, "Investment Transfer", TransactionCatagory.Transfers ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 2, 27 ), 12.50m, "ATM Fee", TransactionCatagory.Fees ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 3, 1 ), 120.45m, "Fresh Market Groceries", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 3, 2 ), 89.99m, "Weekend Dinner", TransactionCatagory.Restaurants ) );
            Transactions.Add( new Transaction( new DateOnly( 2024, 3, 3 ), 65.10m, "Fuel Station", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2025, 1, 3 ), 520.00m, "January Primary Salary Deposit from Employer ABC Corporation", TransactionCatagory.Income ) );
            Transactions.Add( new Transaction( new DateOnly( 2025, 1, 5 ), 1499.999999m, "Monthly Residential Apartment Lease Payment Including Underground Parking", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2025, 1, 8 ), 0.0000001m, "Interest Adjustment Micro Credit", TransactionCatagory.Income ) );
            Transactions.Add( new Transaction( new DateOnly( 2025, 1, 10 ), 284.456789123m, "Comprehensive Grocery Shopping at Large Wholesale Market Including Bulk Rice, Produce, and Cleaning Supplies", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2025, 1, 14 ), 89.999999999m, "", TransactionCatagory.Entertainment ) ); // empty description edge case
            Transactions.Add( new Transaction( new DateOnly( 2025, 1, 22 ), 15.0000000000000000001m, "Minor Bank Processing Fee Adjustment", TransactionCatagory.Fees ) );

            Transactions.Add( new Transaction( new DateOnly( 2025, 2, 4 ), 67.3400000000000009m, "Fuel Purchase for Vehicle - Premium Gasoline", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2025, 2, 7 ), 145.8754321m, "Medical Prescription and Over-the-Counter Supplies", TransactionCatagory.Healthcare ) );

            Transactions.Add( new Transaction( new DateOnly( 2025, 2, 17 ), 220.123456789m, "Automobile Insurance Installment Plan Payment", TransactionCatagory.Insurance ) );

            Transactions.Add( new Transaction( new DateOnly( 2025, 3, 3 ), 1400.75m, "March Apartment Rental Payment", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2025, 3, 9 ), 75.0000000000000003m, "Streaming Services Annual Subscription Renewal Pro-Rated", TransactionCatagory.Entertainment ) );

            Transactions.Add( new Transaction( new DateOnly( 2025, 6, 10 ), 102.345678901234m, "Weekly Supermarket Restocking Including Fresh Produce and Household Essentials", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2025, 7, 18 ), 480.0000000001m, "Quarterly Debt Installment Payment", TransactionCatagory.Debt ) );


            Transactions.Add( new Transaction( new DateOnly( 2025, 12, 31 ), 1.0000000000000000000000001m, "Year End Adjustment Micro Correction", TransactionCatagory.Fees ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 1, 8 ), 1600.0000000000001m, "Mortgage Installment Including Escrow Portion", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 1, 14 ), 345.876543210987m, "Major Grocery Run for Household and Guests", TransactionCatagory.Groceries ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 2 ), 87.654321m, "Transportation Costs Including Fuel and Parking", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 15 ), 210.123456789012345m, "Healthcare Consultation and Laboratory Services", TransactionCatagory.Healthcare ) );


            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 18 ), 1800.75m, "Consulting Project Payment Installment", TransactionCatagory.Income ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 3 ), 1500.00m, "Primary Housing Rent Payment", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 20 ), 250.50m, "Maintenance Fee Adjustment", TransactionCatagory.Housing ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 4 ), 340.80m, "Bulk Grocery Restock", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 22 ), 145.45m, "Mid-Month Grocery Refill", TransactionCatagory.Groceries ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 5 ), 120.75m, "Fuel and Parking Costs", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 23 ), 98.40m, "Vehicle Service Contribution", TransactionCatagory.Transportation ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 6 ), 210.33m, "Electricity Bill Payment", TransactionCatagory.Utilities ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 24 ), 135.27m, "Water and Waste Services", TransactionCatagory.Utilities ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 7 ), 175.90m, "Dining Out Weekend", TransactionCatagory.Restaurants ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 21 ), 140.60m, "Business Lunch Meeting", TransactionCatagory.Restaurants ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 8 ), 300.00m, "Insurance Premium Installment", TransactionCatagory.Insurance ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 25 ), 125.99m, "Policy Adjustment Fee", TransactionCatagory.Insurance ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 9 ), 420.00m, "Loan Repayment", TransactionCatagory.Debt ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 26 ), 215.25m, "Credit Card Balance Payment", TransactionCatagory.Debt ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 10 ), 150.00m, "Concert Tickets", TransactionCatagory.Entertainment ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 27 ), 89.99m, "Streaming and Media Subscription Renewal", TransactionCatagory.Entertainment ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 11 ), 230.45m, "Medical Appointment and Lab Work", TransactionCatagory.Healthcare ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 28 ), 145.78m, "Prescription Medication Refill", TransactionCatagory.Healthcare ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 12 ), 800.00m, "Savings Account Transfer", TransactionCatagory.Transfers ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 19 ), 450.00m, "Investment Portfolio Allocation", TransactionCatagory.Transfers ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 13 ), 125.50m, "Bank Service Charges and Processing Fees", TransactionCatagory.Fees ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 28 ), 42.75m, "International Transaction Fee", TransactionCatagory.Fees ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 2, 28 ), 1000.00m, "Dog biscuts", TransactionCatagory.Other ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 1 ), 1500.00m, "Monthly Rent Payment", TransactionCatagory.Housing ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 18 ), 75.00m, "Minor Repair Contribution", TransactionCatagory.Housing ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 3 ), 165.40m, "Weekly Grocery Run", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 10 ), 142.75m, "Midweek Refill", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 17 ), 128.20m, "Bulk Produce + Household Items", TransactionCatagory.Groceries ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 25 ), 89.90m, "End of Month Top-Up", TransactionCatagory.Groceries ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 2 ), 95.00m, "Fuel Fill-Up", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 12 ), 120.00m, "Vehicle Maintenance", TransactionCatagory.Transportation ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 22 ), 87.35m, "Fuel + Parking", TransactionCatagory.Transportation ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 5 ), 132.40m, "Electricity Bill", TransactionCatagory.Utilities ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 7 ), 78.15m, "Water & Waste Services", TransactionCatagory.Utilities ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 15 ), 52.99m, "Internet Service", TransactionCatagory.Utilities ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 6 ), 42.80m, "Dinner Out", TransactionCatagory.Restaurants ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 14 ), 65.25m, "Weekend Brunch", TransactionCatagory.Restaurants ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 21 ), 38.90m, "Takeout", TransactionCatagory.Restaurants ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 29 ), 55.10m, "Family Dinner", TransactionCatagory.Restaurants ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 8 ), 285.00m, "Auto Insurance Installment", TransactionCatagory.Insurance ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 11 ), 400.00m, "Credit Card Payment", TransactionCatagory.Debt ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 9 ), 29.99m, "Streaming Services", TransactionCatagory.Entertainment ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 16 ), 89.50m, "Concert Tickets", TransactionCatagory.Entertainment ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 28 ), 45.00m, "Movie Night", TransactionCatagory.Entertainment ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 4 ), 125.00m, "Dental Cleaning", TransactionCatagory.Healthcare ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 23 ), 98.75m, "Prescription Medication", TransactionCatagory.Healthcare ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 13 ), 500.00m, "Savings Transfer", TransactionCatagory.Transfers ) );
            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 27 ), 300.00m, "Investment Contribution", TransactionCatagory.Transfers ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 30 ), 42.75m, "Bank Service Fees", TransactionCatagory.Fees ) );

            Transactions.Add( new Transaction( new DateOnly( 2026, 3, 20 ), 85.00m, "Pet Supplies", TransactionCatagory.Other ) );
            //To display special letters in polish and french
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;
            Console.CursorVisible = false;

            //itterage through the enum and check the values avaiilable
            transactionCategoryLongestSize = GetTransactionCategoryLongestLength();

            //Initialize budget amounts to 0 before loading from file
            foreach ( TransactionCatagory cat in Enum.GetValues( typeof( TransactionCatagory ) ) ) {
                BudgetCategories.Add( cat, 0 );
            }



            //passed bby refrence to allow manipulating outputMessages
            GetMessages( ref outputMessage, xmlfile, defaultEnglishMessages );
            ColorConsole.WriteLine( outputMessage [ MessageEnum.LabelStarting ], WaitForAcknowledgment: true );


            //Create customer for testing

            //Main Menu Logic and Input Validation

            while ( true ) {

                Console.Clear();
                MainMenuChoice();
                switch ( Console.ReadKey( intercept: true ).Key ) {

                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        TransactionManagement();
                        break;
                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        BudgetMenu();
                        break;
                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:
                        ReportsAndSummary();
                        break;
                    case ConsoleKey.D4:
                    case ConsoleKey.NumPad4:
                    case ConsoleKey.Escape:
                    case ConsoleKey.Backspace:
                        Console.WriteLine();
                        ColorConsole.WriteLine( outputMessage [ MessageEnum.LabelExit ], colorByGroup [ ColorGroup.SystemExit ], ColorAfterFg: ConsoleColor.White, ColorAfterBg: ConsoleColor.Black, WaitForAcknowledgment: true );
                        Environment.Exit( 0 );
                        break;

                }
            }
        }
        private static void BudgetMenu( bool dontClearOnDraw = false ) {
            while ( true ) {
                //Clear the screen weather returning or from a different menu (Main Menu)
                if ( !dontClearOnDraw )
                    Console.Clear();
                int padding = 8;
                Console.WriteLine( "---- Monthly Budget ----" );
                (int Left, int Top) consolePosItem = Console.GetCursorPosition(); //uses a tuple
                consolePosItem.Left = transactionCategoryLongestSize + padding + 1;
                budgetMenuDisplay( padding: padding );
                Console.WriteLine( "Instructions: Press a menu key above, type in your number and press enter to update. You can press ESC while typing to stop updating that budget category without manking changes." );
                Console.WriteLine( "When you are editing you will see a blank white box. A warning will show if your transactions are near or suprass your budget this month/category." );
                Console.WriteLine();
                (int Left, int Top) consolePosRest = Console.GetCursorPosition(); //uses a tuple
                bool msgFlag = false;

                while ( true ) {
                    int cursorActivePos = 0;    //initiating
                    int keyOffset = 0;          //to make code reusable for 3 key ranges and flag when proper key pressed
                    ConsoleKeyInfo keyInfo = Console.ReadKey( intercept: true );

                    if ( msgFlag ) {
                        Console.SetCursorPosition( consolePosRest.Left, consolePosRest.Top );
                        Console.Write( new string( ' ', Console.BufferWidth ) );
                    }

                    //3 sets of key ranges, setting their offset
                    if ( keyInfo.Key > ConsoleKey.D0 && keyInfo.Key <= ConsoleKey.D9 ) {
                        keyOffset = 49;
                        cursorActivePos = consolePosItem.Top + ( ( ( int ) keyInfo.Key - keyOffset ) * 2 );
                    }
                    if ( keyInfo.Key > ConsoleKey.NumPad0 && keyInfo.Key <= ConsoleKey.NumPad9 ) {
                        keyOffset = 97;
                        cursorActivePos = consolePosItem.Top + ( ( ( int ) keyInfo.Key - keyOffset ) * 2 );
                    }
                    if ( keyInfo.Key >= ConsoleKey.A && keyInfo.Key <= ConsoleKey.D ) {
                        keyOffset = 65;
                        cursorActivePos = consolePosItem.Top + ( ( ( int ) keyInfo.Key - keyOffset + 9 ) * 2 );
                    }
                    if ( keyInfo.Key == ConsoleKey.Escape || keyInfo.Key == ConsoleKey.Q ) {
                        Console.Clear();
                        Console.WriteLine( "Budgets updated!" );
                        return;
                    }
                    if ( keyOffset != 0 ) {

                        TransactionCatagory item = ( TransactionCatagory ) ( int ) keyInfo.Key - keyOffset + 1;

                        overWriteItem( BudgetCategories [ item ].ToString( "C" ).Length, saved_num: false );


                        //clean up the area and return back to starting Active postion

                        bool dotUsed = false;
                        string numberToParse = "";
                        bool updateValue = false;
                        int maxLen = 9;
                        while ( true ) {
                            //Set up info for keys. future exapanding could just print the numberToParse from start position over and over.
                            //and just manipulate the string
                            ConsoleKeyInfo keyInfoWrite = Console.ReadKey( intercept: true );
                            ConsoleKey keyWrite = keyInfoWrite.Key;
                            var keyWriteChar = keyInfoWrite.KeyChar;
                            if ( keyWrite == ConsoleKey.Escape || keyWrite == ConsoleKey.Q ) {
                                updateValue = false;
                                break;
                            }
                            //If user enters a number or || a decimal just once
                            if ( char.IsNumber( keyWriteChar ) || ( keyWriteChar == '.' && dotUsed == false ) ) {
                                if ( numberToParse.Length < maxLen ) {
                                    //Only one period allowed
                                    if ( keyWriteChar == '.' ) {
                                        dotUsed = true;
                                    }
                                    // Update number to parse, write it and always add a padding. (Then resets back before the padding)
                                    numberToParse += keyWriteChar.ToString();
                                    ColorConsole.Write( keyWriteChar.ToString(), colorByGroup [ ColorGroup.InputStyleA ] );
                                    ColorConsole.Write( " ", colorByGroup [ ColorGroup.InputStyleA ] );
                                    Console.CursorLeft -= 1;
                                } else {
                                    // print message that number is too large
                                    msgFlag = true;
                                    overWrite( $"Your number currnet can not exceed {Convert.ToDecimal( new string( '9', maxLen ) ) + 0.99M:C}, subscribe to premium product for that" );
                                    Console.SetCursorPosition( consolePosRest.Left, consolePosRest.Top );
                                }
                            }
                            //User Deletes or Enters
                            if ( numberToParse.Length > 0 ) {
                                //Delete
                                if ( keyWrite == ConsoleKey.Backspace ) {
                                    //Will remove any messages at the bottom if they exist
                                    if ( msgFlag ) {
                                        Console.SetCursorPosition( consolePosRest.Left, consolePosRest.Top );
                                        Console.Write( new string( ' ', Console.BufferWidth ) );
                                        Console.SetCursorPosition( consolePosItem.Left + numberToParse.Length, cursorActivePos );
                                        msgFlag = false;

                                    }
                                    //Will allow decimal once deleted
                                    if ( numberToParse.Last() == '.' ) {
                                        dotUsed = false;
                                    }
                                    #region /// Clear Typed number using Cursot Left
                                    Console.CursorLeft -= 1;
                                    ColorConsole.Write( " ", colorByGroup [ ColorGroup.InputStyleA ] );
                                    Console.CursorLeft -= 1;
                                    //remove the last letter
                                    numberToParse = numberToParse.Substring( 0, numberToParse.Length - 1 );
                                    #endregion
                                }
                                //Enter numbber
                                if ( keyWrite == ConsoleKey.Enter ) {
                                    overWrite( "Updated Budget!" );
                                    updateValue = true;
                                    break;
                                }
                            }

                            //Moves cursor to write a message at the bottom and places back at the start of the budget item being editied
                            void overWrite( string msg ) {
                                Console.SetCursorPosition( consolePosRest.Left, consolePosRest.Top );
                                msgFlag = true;
                                Console.Write( msg );
                                Console.SetCursorPosition( consolePosItem.Left + numberToParse.Length, cursorActivePos );
                            }
                        }
                        //Entered number time to validate!
                        if ( updateValue ) {
                            decimal pass = 0;
                            if ( decimal.TryParse( numberToParse, out pass ) ) {
                                BudgetCategories [ item ] = pass;
                            }
                        }
                        overWriteItem( saved_num: true );


                        // Triger the way it is displayed
                        budgetWarning( item, consolePosItem, padding );


                        //Will clear the line or print or velue stored in memory. Used for page on open and if user escapes input. Restore
                        void overWriteItem( int paddingLength = 0, bool saved_num = true ) {
                            Console.CursorLeft = consolePosItem.Left;
                            Console.CursorTop = cursorActivePos;
                            string printVal = saved_num ? BudgetCategories [ item ].ToString( "C" ) + " " : new string( ' ', paddingLength + 1 );
                            ColorConsole.Write( printVal, colorByGroup [ ColorGroup.InputStyleA ] );
                            ColorConsole.Write( new string( ' ', Console.BufferWidth - printVal.Length - transactionCategoryLongestSize - 3 - padding ) );
                            Console.CursorLeft = consolePosItem.Left;
                        }

                    }
                }





            }
        }
        private static void budgetWarning( TransactionCatagory category, (int Left, int Top) consolePosItem, int padding, bool afterInitial = true ) {
            var today = DateOnly.FromDateTime( DateTime.Today );
            List<Transaction> transforCat = new();
            transforCat = Transactions
.Where( trans =>
trans.Date.Month == today.Month &&
trans.Date.Year == today.Year &&
trans.Catagory == category )
.ToList();
            decimal total = transforCat.Sum( t => t.Amount );
            if ( total > 1m * BudgetCategories [ category ] ) {
                if ( afterInitial )
                    Console.CursorLeft = consolePosItem.Left + 18;
                ColorConsole.Write( $" 100% over budget in this category. Total: {total} for this {today.ToString( "MMMM" )} ", colorByGroup [ ColorGroup.SystemError ] );
                if ( afterInitial )
                    Console.CursorLeft = consolePosItem.Left;
            } else
                if ( total > 0.8m * BudgetCategories [ category ] ) {
                    if ( afterInitial )
                        Console.CursorLeft = consolePosItem.Left + 18;

                    ColorConsole.Write( $" 80% over budget in this category. Total: {total} for this {today.ToString( "MMMM" )} ", colorByGroup [ ColorGroup.SystemError ] );
                    if ( afterInitial )
                        Console.CursorLeft = consolePosItem.Left;
                } else {
                    if ( afterInitial ) {
                        Console.CursorLeft = consolePosItem.Left + 18;
                        ColorConsole.Write( new string( ' ', Console.BufferWidth - 3 - transactionCategoryLongestSize - padding - 18 ), colorByGroup [ ColorGroup.Default ] );


                        Console.CursorLeft = consolePosItem.Left;
                    }

                }

        }
        private static void budgetMenuDisplay( int padding ) {

            //Print menu
            char ConsoleKeychar = '1'; //starts at digit 1
            bool start = true;
            foreach ( TransactionCatagory cat in Enum.GetValues( typeof( TransactionCatagory ) ) ) {
                if ( !start ) {
                    if ( ConsoleKeychar == '9' + 1 ) {
                        ConsoleKeychar = 'A';
                    }

                    ColorConsole.Write( ConsoleKeychar.ToString(), colorByGroup [ ColorGroup.MenuItems ], ResetColorAfter: false );
                    Console.Write( ". " + cat.ToString() );
                    Console.CursorLeft = transactionCategoryLongestSize + padding;

                    ColorConsole.Write( " ", colorByGroup [ ColorGroup.InputStyleA ], ResetColorAfter: false );
                    Console.Write( BudgetCategories [ cat ].ToString( "C" ) );
                    Console.Write( " " );
                    ColorConsole.Write( "            ", colorByGroup [ ColorGroup.Default ], ResetColorAfter: false );
                    budgetWarning( cat, (0, 0), padding, afterInitial: false );
                    ColorConsole.WriteLine( "\n", colorByGroup [ ColorGroup.Default ], ResetColorAfter: false );
                    ConsoleKeychar++;
                } else { start = false; }
            }

        }
        /// <summary>
        /// Will need to return something probably, dontClearOnDraw Allows for you to leave the last screen showing. Good for allowing a lingering return message.
        /// </summary>
        private static void TransactionManagement( bool dontClearOnDraw = false ) {
            while ( true ) {
                //Clear the screen weather returning or from a different menu (Main Menu)
                if ( !dontClearOnDraw )
                    Console.Clear();
                TransactionManagementMenuChoice();
                switch ( Console.ReadKey( intercept: true ).Key ) {
                    //Add Income
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        dontClearOnDraw = AddIncomeExpenseTransaction( IncomeOrExpense.Income );
                        break;
                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        dontClearOnDraw = AddIncomeExpenseTransaction( IncomeOrExpense.Expense );
                        break;
                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:
                        ViewTransactions( Transactions, rearrangeList: true );
                        break;
                    case ConsoleKey.D4:
                    case ConsoleKey.NumPad4:
                        SearchByTransactions(); //Uses view transaction
                        break;
                    case ConsoleKey.D5:
                    case ConsoleKey.NumPad5:
                    case ConsoleKey.Escape:
                    case ConsoleKey.Backspace:
                        return;

                }
            }
        }
        private static void SearchByTransactions() {
            Console.Clear();
            SearchType searchby = SearchType.Category;
            ColorConsole.WriteLine( "How would you like to search transactions?", colorByGroup [ ColorGroup.Header ] );
            Console.WriteLine();
            ColorConsole.WriteLine( "1. By category", colorByGroup [ ColorGroup.MenuItems ] );
            ColorConsole.WriteLine( "2. By date range", colorByGroup [ ColorGroup.MenuItems ] );
            ColorConsole.WriteLine( "3. By amount range", colorByGroup [ ColorGroup.MenuItems ] );
            ColorConsole.WriteLine( "\nOptions\n" );
            ColorConsole.WriteLine( "A. Order results by Ascending (Larger value @ end of list)", colorByGroup [ ColorGroup.MenuItems ] );
            ColorConsole.WriteLine( "B. Order results by Descending (Larger value @ start of list)", colorByGroup [ ColorGroup.MenuItems ] );
            ColorConsole.WriteLine( "C. Color band each item alternating", colorByGroup [ ColorGroup.MenuItems ] );

            Console.WriteLine();
            ColorConsole.Write( "(Press q or esc to exit)", colorByGroup [ ColorGroup.SystemInstructionsAnyKey ] );
            ColorConsole.Write( " Press: 1, 2, or 3 : Options Set  ", ConsoleColor.White );
            int cursorPos = Console.CursorLeft;
            Console.Write( "A | C" );
            int [ ] OptionPosInListOrder = [ 0, 0, 4 ];
            int endindex = 6;
            bool toggleA = true;
            bool toggleBDecending = false;
            bool toggleCColorBand = true;
            while ( true ) {
                ConsoleKeyInfo key = Console.ReadKey( intercept: true );
                if ( key.Key == ConsoleKey.Q || key.Key == ConsoleKey.Escape ) {
                    return;
                }
                if ( key.Key == ConsoleKey.NumPad1 || key.Key == ConsoleKey.D1 ) {
                    break;
                }
                if ( key.Key == ConsoleKey.NumPad2 || key.Key == ConsoleKey.D2 ) {
                    searchby = SearchType.DateRange;
                    break;
                }
                if ( key.Key == ConsoleKey.NumPad3 || key.Key == ConsoleKey.D3 ) {
                    searchby = SearchType.PriceRange;
                    break;

                }
                if ( key.Key == ConsoleKey.A ) {
                    if ( toggleBDecending ) {
                        toggleBDecending = false;
                        Console.CursorLeft = cursorPos;
                    }
                    if ( !toggleA ) {
                        toggleA = true;
                        Console.Write( "A" );
                    }
                    Console.CursorLeft = cursorPos + endindex;
                }
                if ( key.Key == ConsoleKey.B ) {
                    if ( toggleA ) {
                        toggleA = false;
                        Console.CursorLeft = cursorPos;
                    }
                    if ( !toggleBDecending ) {
                        toggleBDecending = true;
                        Console.Write( "B" );
                    }
                    Console.CursorLeft = cursorPos + endindex;
                }
                if ( key.Key == ConsoleKey.C ) {
                    toggleCColorBand = !toggleCColorBand;
                    if ( toggleCColorBand ) {

                        Console.CursorLeft = cursorPos + OptionPosInListOrder [ 2 ];
                        Console.Write( "C" );
                    } else {

                        Console.CursorLeft = cursorPos + OptionPosInListOrder [ 2 ];
                        Console.Write( " " );

                    }
                    Console.CursorLeft = cursorPos + endindex;
                }
            }

            //Logical portion
            Console.Clear();
            List<Transaction> orderedTrans;
            switch ( searchby ) {
                case SearchType.PriceRange:
                    decimal amt1 = 0m;
                    decimal amt2 = 0m;
                    if ( GetAmount( ref amt1, allowInputZero: true ) ) {
                        return;
                    }
                    if ( GetAmount( ref amt2, allowInputZero: true ) ) {
                        return;
                    }
                    ;
                    //Keeping the order low
                    if ( amt1 > amt2 ) {
                        decimal amtTemp = amt1;
                        amt1 = amt2;
                        amt2 = amtTemp;
                    }
                    //triger order it is displayed
                    if ( toggleBDecending ) {
                        orderedTrans = ( from trans in Transactions
                                         where trans.Amount >= amt1 && trans.Amount <= amt2
                                         orderby trans.Amount descending
                                         select trans ).ToList();
                    } else {
                        orderedTrans = ( from trans in Transactions
                                         where trans.Amount >= amt1 && trans.Amount <= amt2
                                         orderby trans.Amount ascending
                                         select trans ).ToList();
                    }

                    //orderedTrans.Reverse(); //tried LINQ decending but didnt seem to work.
                    if ( orderedTrans.Count > 0 ) {

                        if ( ViewTransactions( orderedTrans, "(By Price Range)", colorBand: toggleCColorBand ) ) {
                            return;
                        }
                    } else {
                        Console.WriteLine( "The search did not return any reuslts! Would you like to search again (implment later)" );
                        AnyKeyToContinue();
                    }
                    break;
                case SearchType.Category:
                    TransactionCatagory cat = new();
                    if ( GetCategory( ref cat ) ) {
                        return;
                    }
                    // Triger the way it is displayed
                    if ( toggleBDecending ) {
                        orderedTrans = ( from trans in Transactions
                                         where trans.Catagory == cat
                                         orderby trans.Date ascending
                                         select trans ).ToList();
                    } else {
                        orderedTrans = ( from trans in Transactions
                                         where trans.Catagory == cat
                                         orderby trans.Date descending
                                         select trans ).ToList();
                    }
                    if ( orderedTrans.Count > 0 ) {
                        if ( ViewTransactions( orderedTrans, "(By Catergory)", colorBand: toggleCColorBand ) ) {
                            return;
                        }
                    } else {
                        Console.WriteLine( "The search did not return any reuslts! Would you like to search again (implment later)" );
                        AnyKeyToContinue();
                    }
                    break;
                case SearchType.DateRange:
                    ColorConsole.WriteLine( "Enter the first date in a date range", colorByGroup [ ColorGroup.Header ] );
                    Console.WriteLine();
                    DateOnly date1 = new();
                    DateOnly date2 = new();
                    if ( GetDate( ref date1 ) ) {
                        return;
                    }
                    Console.Clear();
                    ColorConsole.WriteLine( "your first date is : " + date1.ToString( dateFormatOut.Item1 ), colorByGroup [ ColorGroup.Header ] );
                    ColorConsole.WriteLine( "Enter the second date in a date range", colorByGroup [ ColorGroup.Header ] );
                    if ( GetDate( ref date2, compareDate: ref date1 ) ) {
                        return;
                    }

                    // Triger the way it is displayed
                    if ( toggleBDecending ) {
                        orderedTrans = ( from trans in Transactions
                                         where trans.Date >= date1 && trans.Date <= date2
                                         orderby trans.Date ascending
                                         select trans ).ToList();
                    } else {
                        orderedTrans = ( from trans in Transactions
                                         where trans.Date >= date1 && trans.Date <= date2
                                         orderby trans.Date descending
                                         select trans ).ToList();
                    }
                    if ( orderedTrans.Count > 0 ) {
                        ViewTransactions( orderedTrans, "(By Date Range)", colorBand: toggleCColorBand );
                    } else {
                        Console.WriteLine( "The search did not return any rsults! Would you like to search again (implment later)" );
                        AnyKeyToContinue();
                    }
                    break;
            }

        }
        private static bool ViewTransactions( List<Transaction> passedTransactions, string Label = "", bool rearrangeList = false, bool colorBand = true ) {
            Label = string.IsNullOrEmpty( Label ) ? "" : System.String.Concat( " ", Label );
            ScrollType scroller = ScrollType.Pager;
            Console.Clear();
            ColorConsole.WriteLine( "How would you like to view the content?", colorByGroup [ ColorGroup.Header ] );
            Console.WriteLine();
            ColorConsole.WriteLine( "1. Display full list (Scroll)", colorByGroup [ ColorGroup.MenuItems ] );
            ColorConsole.WriteLine( "2. Display by pages (Change)", colorByGroup [ ColorGroup.MenuItems ] );
            ColorConsole.WriteLine( "3. Display full list with page breaks (Both)", colorByGroup [ ColorGroup.MenuItems ] );
            Console.WriteLine();
            ColorConsole.Write( "(Press q or esc to exit)", colorByGroup [ ColorGroup.SystemInstructionsAnyKey ] );
            ColorConsole.Write( " 1, 2, or 3 ", ConsoleColor.White );

            while ( true ) {
                ConsoleKeyInfo key = Console.ReadKey( intercept: true );
                if ( key.Key == ConsoleKey.Q || key.Key == ConsoleKey.Escape ) {
                    return true;
                }
                if ( key.Key == ConsoleKey.NumPad1 || key.Key == ConsoleKey.D1 ) {
                    scroller = ScrollType.Scroller;
                    break;
                }
                if ( key.Key == ConsoleKey.NumPad2 || key.Key == ConsoleKey.D2 ) {
                    //default initiatated at top
                    break;
                }
                if ( key.Key == ConsoleKey.NumPad3 || key.Key == ConsoleKey.D3 ) {

                    scroller = ScrollType.Both;
                    break;

                }
            }
            Console.Clear();

            //Sort by date into new list
            List<Transaction> SortedTransactions = passedTransactions;
            if ( rearrangeList ) {
                SortedTransactions.Sort( ( s1, s2 ) => s1.Date.CompareTo( s2.Date ) );
            }

            //for checking length
            int maxLenAmount = 0;
            int maxLenCat = 14;

            //May appear unnesscary, but if we change setting in other part of program for long dates we will still space out properly.
            int maxLenDate = dateFormatOut.Item2;
            foreach ( Transaction transaction in SortedTransactions ) {

                //Formats as currency then captures the longest one
                int amountLen = transaction.Amount.ToString( "C" ).Length;
                int catLen = Enum.GetName( transaction.Catagory ).Length;

                //Increases if Mac amoutn is smaller
                if ( maxLenAmount < amountLen )
                    maxLenAmount = amountLen;

            }

            //height of the window before printing for overflow
            int bufHeight = Console.WindowHeight;

            int pgCount = 1;
            int nonitemLines = 4;
            int pgMax = SortedTransactions.Count / ( bufHeight - nonitemLines );
            int pgRemainder = SortedTransactions.Count % ( bufHeight - nonitemLines );
            if ( pgRemainder > 0 )
                pgMax++;

            if ( scroller == ScrollType.Scroller ) {
                ColorConsole.WriteLine( $"------------ Viewing all Transactions{Label} ------------", colorByGroup [ ColorGroup.Header ] );
            } else {
                ColorConsole.WriteLine( $"------------ Viewing all Transactions{Label} ( Pg : {pgCount}/{pgMax} ) ------------", colorByGroup [ ColorGroup.Header ] );
            }
            //Length of Labels (based on language)
            int dateLabelLen = outputMessage [ MessageEnum.LabelDate ].ToString().Length;
            int amtLabelLen = outputMessage [ MessageEnum.LabelAmount ].ToString().Length;
            int descLabelLen = outputMessage [ MessageEnum.LabelDescription ].ToString().Length;
            int catLabelLen = outputMessage [ MessageEnum.LabelCategory ].ToString().Length;
            //Length of batting between items, later write line will use something like " | " 3 per item-1 = 9;
            string headerSpacer = "     ";
            string bodySpacer = "  |  ";
            int totalPaddingLength = headerSpacer.Length * 3;

            //Overall padding available after longes printed items considered. (ie if the descriptions are short, or the amounts etc)
            int maxLenDesc = Console.BufferWidth - ( maxLenAmount + maxLenCat + maxLenDate + totalPaddingLength );


            //Sepcify header padding lengs

            string datePadding = new( ' ', maxLenDate - dateLabelLen );
            string descPadding = new( ' ', maxLenDesc - descLabelLen );
            string categoryPadding = new( ' ', maxLenCat - catLabelLen );
            //Amout is last so padding not required

            //Write the header
            Writeheader(); //found at end
            //Writes each transation formated
            int lineCount = 1;
            int evenodd = 0;
            int i = 0;
            int [ ] index_start_page = new int [ pgMax ];
            while ( true ) {
                if ( lineCount == 1 ) {
                    index_start_page [ pgCount - 1 ] = i;
                }
                //SCROLLER - Exit when whole list is printed and using scrolling tpye
                if ( i > SortedTransactions.Count - 1 && scroller == ScrollType.Scroller ) {
                    Console.ForegroundColor = colorByGroup [ ColorGroup.SystemInstructionsAnyKey ] [ 0 ];
                    AnyKeyToContinue();
                    return false;

                }
                //Get Transaction to print
                Transaction transaction = SortedTransactions.ElementAt( i );


                //Optional color banding. Defualt is active
                if ( colorBand ) {
                    Console.ForegroundColor = evenodd == 0 ? ConsoleColor.Green : ConsoleColor.Cyan;
                    evenodd = ( evenodd == 0 ) ? 1 : 0;
                } else {
                    if ( i == 0 ) {
                        Console.ForegroundColor = ConsoleColor.Green;
                    }
                }


                //Printing out Details in single row
                #region///Print Date Formated
                Console.Write( transaction.Date.ToString( dateFormatOut.Item1 ) );
                Console.Write( new string( ' ', maxLenDate - transaction.Date.ToString( dateFormatOut.Item1 ).Length ) + bodySpacer ); //sapcer
                #endregion
                #region ///Print Category        - Add spaces if not the max size, print spacer 3 chars

                Console.Write( transaction.Catagory );
                //Max length - the actual legnth+ 3 for padding. So if the longest word is 12, and we have gas (3), should fill 9 spaces + 3 spaces.
                if ( ( maxLenCat - Enum.GetName( transaction.Catagory ).Length ) > 0 )
                    Console.Write( new string( ' ', maxLenCat - Enum.GetName( transaction.Catagory ).Length ) );
                Console.Write( bodySpacer );
                #endregion
                #region ///Print Description
                string discOutTrucled = transaction.Description;
                if ( transaction.Description.ToString().Length > maxLenDesc - 3 ) {
                    discOutTrucled = discOutTrucled.Substring( 0, maxLenDesc - 3 );
                    Console.Write( discOutTrucled + "..." );
                } else {
                    Console.Write( discOutTrucled );
                    Console.Write( new string( ' ', maxLenDesc - discOutTrucled.Length ) );
                }
                Console.Write( bodySpacer );
                #endregion
                #region ///Print Amount
                Console.WriteLine( transaction.Amount.ToString( "C" ) );
                //Console.WriteLine( i );
                #endregion

                if ( scroller == ScrollType.Pager || scroller == ScrollType.Both ) {
                    //Last Transaction on las page Printed
                    if ( pgCount == pgMax && i == SortedTransactions.Count - 1 ) {
                        ColorConsole.Write( "Prev. Page > Up Arrow, Left Arrow, Page Up  | Next Page > Down Arrow, right Arrow, Page Down | Exit > Esc, q, Backspace", colorByGroup [ ColorGroup.SystemInstructionsAnyKey ] );

                        //Update remainder to normalize the 0 in modulus
                        int remainder = ( pgRemainder == 0 ) ? ( bufHeight - nonitemLines ) : pgRemainder;

                        //print blank lines as needed this is for spacing out the return key may not even be needed, style prefrence
                        for ( int e = 0; e < bufHeight - nonitemLines - remainder; e++ ) {
                            Console.WriteLine( "" );

                        }

                        int toTop = 0;
                        //Navigation controls for the last page
                        while ( true ) {
                            ConsoleKeyInfo key = Console.ReadKey( true );
                            //Go back a page as long as its not page 1!
                            if ( pgMax != 1 && ( key.Key == ConsoleKey.PageUp || key.Key == ConsoleKey.LeftArrow || key.Key == ConsoleKey.UpArrow ) ) {
                                pgCount--;
                                lineCount = 1;
                                i = index_start_page [ pgCount - 1 ];
                                toTop = 1;
                                if ( scroller == ScrollType.Pager ) {
                                    Console.Clear();
                                }

                                ColorConsole.WriteLine( $"------------ Viewing all Transactions{Label} (continuing Pg : {pgCount}/{pgMax} ) ------------", colorByGroup [ ColorGroup.Header ] );
                                Writeheader();
                                break;
                            }
                            //exit by command
                            if ( key.Key == ConsoleKey.Escape || key.Key == ConsoleKey.Backspace || key.Key == ConsoleKey.Q ) {
                                toTop = 2;
                                break;
                            }

                        }

                        if ( toTop == 2 ) {
                            break;
                        }

                        if ( toTop == 1 ) {
                            continue;
                        }
                    }


                    #region ///Each Page finished except the last
                    if ( lineCount == bufHeight - nonitemLines ) {       //Screen full
                        lineCount = 0;
                        Console.ForegroundColor = ConsoleColor.Gray;
                        ColorConsole.Write( "Prev. Page > Up Arrow, Left Arrow, Page Up  | Next Page > Down Arrow, right Arrow, Page Down | Exit > Esc, q, Backspace", colorByGroup [ ColorGroup.SystemInstructionsAnyKey ] );
                        int toTop = 0; //Used to track itteration of master for loop. (this scope)
                        while ( toTop == 0 ) {
                            ConsoleKeyInfo key = Console.ReadKey( true );

                            //Not first page (Can go back a page)
                            if ( pgCount > 1 && ( key.Key == ConsoleKey.PageUp || key.Key == ConsoleKey.LeftArrow || key.Key == ConsoleKey.UpArrow ) ) {
                                pgCount--;
                                lineCount = 1;
                                i = index_start_page [ pgCount - 1 ];
                                toTop = 1;
                            }
                            if ( ( pgCount < pgMax && key.Key == ConsoleKey.PageDown ) || key.Key == ConsoleKey.RightArrow || key.Key == ConsoleKey.DownArrow ) {
                                pgCount++;
                                break; //bypass toTop control to print header
                            }
                            if ( key.Key == ConsoleKey.Escape || key.Key == ConsoleKey.Backspace || key.Key == ConsoleKey.Q )
                                toTop = 2;
                        }


                        if ( scroller == ScrollType.Pager ) {
                            Console.Clear();
                        }


                        ColorConsole.WriteLine( $"------------ Viewing all Transactions{Label} (continuing Pg : {pgCount}/{pgMax} ) ------------", colorByGroup [ ColorGroup.Header ] );

                        Writeheader();

                        //Back to loop start with updated variables
                        if ( toTop == 1 ) {
                            toTop = 0;
                            continue;
                        }
                        //exit
                        if ( toTop == 2 ) {
                            break;
                        }
                    }
                    #endregion
                }

                lineCount++;
                i++;

            }
            void Writeheader() {
                //Write the header

                ColorConsole.Write( outputMessage [ MessageEnum.LabelDate ] + datePadding + headerSpacer, ConsoleColor.Red, ResetColorAfter: false );
                Console.Write( outputMessage [ MessageEnum.LabelCategory ] + categoryPadding + headerSpacer );
                Console.Write( outputMessage [ MessageEnum.LabelDescription ] + descPadding + headerSpacer );
                Console.WriteLine( outputMessage [ MessageEnum.LabelAmount ] );
                Console.WriteLine();
            }
            return false;
        }
        /// <summary>
        /// Will need to return something probably, dontClearOnDraw Allows for you to leave the last screen showing. Good for allowing a lingering return message.
        /// </summary>
        private static bool AddIncomeExpenseTransaction( IncomeOrExpense type ) {
            string transType = Enum.GetName<IncomeOrExpense>( type );

            Console.Clear();
            decimal amount = 0m;

            DateOnly date = new();
            string descriptionInput;
            TransactionCatagory cat = new();

            ///Prints an exit message

            //heading
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.LabelAddIncomeTransaction ]} ------------", MenuHeadings );

            if ( type == IncomeOrExpense.Expense ) {
                if ( GetCategory( ref cat ) ) {
                    Console.Clear();
                    ColorConsole.WriteLine( $"------------ Transaction aborted ------------", colorByGroup [ ColorGroup.SystemExit ] );
                    return true;
                }
            }

            if ( GetAmount( ref amount ) ) {
                Console.Clear();
                ColorConsole.WriteLine( $"------------ Transaction aborted ------------", colorByGroup [ ColorGroup.SystemExit ] );
                return true;
            }
            //Ask Description
            while ( true ) {
                ColorConsole.Write( outputMessage [ MessageEnum.SystemInstructionsAbort ], colorByGroup [ ColorGroup.SystemInstructions ] );
                ColorConsole.Write( $" {outputMessage [ MessageEnum.SystemInstructionsInputTransDescritption ]} : " );
                descriptionInput = ColorConsole.ReadLine();
                // user typed exit in native language, returning
                if ( descriptionInput == outputMessage [ MessageEnum.LabelExit ] ) {
                    Console.Clear();
                    ColorConsole.WriteLine( $"------------ Transaction aborted ------------", colorByGroup [ ColorGroup.SystemExit ] );

                    return true;
                }

                if ( string.IsNullOrWhiteSpace( descriptionInput ) ) {
                    descriptionInput = "No description provided";
                } else
                    break;
            }
            //Ask Date
            if ( GetDate( ref date ) ) {
                Console.Clear();
                ColorConsole.WriteLine( $"------------ Transaction aborted ------------", colorByGroup [ ColorGroup.SystemExit ] );
                return true;
            }

            //create new transaction and display it, wait for user to confirm before going back to transaction management menu
            if ( type == IncomeOrExpense.Expense )
                Transactions.Add( new Transaction( date, amount, descriptionInput, cat ) );

            else
                Transactions.Add( new Transaction( date, amount, descriptionInput ) );
            Console.Clear();

            //Seperates labels and colors them based on systeminstructions Colors
            ColorConsole.WriteLine( $" {outputMessage [ MessageEnum.TransMgnt_TransactionAdded ]} : {transType} ", colorByGroup [ ColorGroup.Success ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.LabelDate ]} : ", colorByGroup [ ColorGroup.SystemInstructions ] );
            Console.WriteLine( $"{Transactions.Last().Date}, " );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.LabelAmount ]} : ", colorByGroup [ ColorGroup.SystemInstructions ] );
            Console.WriteLine( $"{Transactions.Last().Amount.ToString( "C" )}, " ); //formats as currency of the system.
            ColorConsole.Write( $"{outputMessage [ MessageEnum.LabelDescription ]} : ", colorByGroup [ ColorGroup.SystemInstructions ] );
            ColorConsole.WriteLine( $"{Transactions.Last().Description}" );
            if ( type == IncomeOrExpense.Expense ) {
                ColorConsole.Write( $"Transaction Category : ", colorByGroup [ ColorGroup.SystemInstructions ] );
                if ( Transactions.Last().Catagory is not 0 ) {
                    ColorConsole.Write( $"{Enum.GetName<TransactionCatagory>( Transactions.Last().Catagory )}" );
                }
            }
            ColorConsole.Write( "", WaitForAcknowledgment: true );
            return false;

        }

        //Print Various Menu Options
        /// <summary>
        /// Main menu for making choices. Returns a string for the State Logic to decide. No validation on this end, except not null.
        /// </summary>
        /// <returns>String of the users input, unvalidated.</returns>
        private static void MainMenuChoice() {


            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_Label ]} ------------", MenuHeadings );
            ColorConsole.WriteLine( "\t1 - " + outputMessage [ MessageEnum.MainMenu_TransactionManagement ], MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t2 - " + outputMessage [ MessageEnum.MainMenu_BudgetTools ] );
            ColorConsole.WriteLine( "\t3 - " + outputMessage [ MessageEnum.MainMenu_ReportsAndSummary ] );
            ColorConsole.WriteLine( "\t4 - " + outputMessage [ MessageEnum.LabelExit ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.LabelPress ]} 1, 2, 3, {outputMessage [ MessageEnum.LabelOr ]} 4", ConsoleColor.White );
            //will leave color as is next command in flow should reset the color to desired
        }
        /// <summary>
        /// Transaction Management Menu for making choices. Returns a string for the State Logic to decide. No validation on this end, except not null.
        /// </summary>
        /// <returns>String of the users input, unvalidated.</returns>
        private static void TransactionManagementMenuChoice() {
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_TransactionManagement ]} ------------", MenuHeadings );
            ColorConsole.WriteLine( "\t1 - " + outputMessage [ MessageEnum.TransMgnt_AddIncomeTransaction ], MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t2 - " + outputMessage [ MessageEnum.TransMgnt_AddExpenseTransaction ] );
            ColorConsole.WriteLine( "\t3 - " + outputMessage [ MessageEnum.TransMgnt_ViewAllTransactions ] );
            ColorConsole.WriteLine( "\t4 - " + outputMessage [ MessageEnum.TransMgnt_SearchTransactions ] );
            ColorConsole.WriteLine( "\t5 - " + outputMessage [ MessageEnum.Menu_Return ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.LabelPress ]} 1, 2, 3, 4 {outputMessage [ MessageEnum.LabelOr ]} 5", ConsoleColor.White );
            //will leave color as is next command in flow should reset the color to desired
        }
        private static void ReportsAndSummary() {
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_ReportsAndSummary ]} ------------", MenuHeadings );
            ColorConsole.WriteLine( "\t1. Account Overview", MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t2. Monthly summary", MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t3. Save Account summay and 12 monthly summaries as Excel Doc", MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t5 - " + outputMessage [ MessageEnum.Menu_Return ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.LabelPress ]} 1, 2, 3, 4 {outputMessage [ MessageEnum.LabelOr ]} 5", ConsoleColor.White );
            //will leave color as is next command in flow should reset the color to desired
        }

        private static Dictionary<TransactionCatagory, decimal> GetTransactionCategoryTotals() {
            Dictionary<TransactionCatagory, decimal> TransCatTotals = new();
            //Loop through each Catagory Type
            decimal highestTotal = 0;
            foreach ( TransactionCatagory cat in Enum.GetValues( typeof( TransactionCatagory ) ) ) {
                //Skip income

                if ( cat != 0 ) {
                    decimal totalCategorySum = ( from trans in Transactions
                                                 where trans.Catagory == cat
                                                 select trans ).Sum( trans => trans.Amount );


                    if ( totalCategorySum > highestTotal ) { //If greater then drop whole list
                        TransCatTotals.Clear();
                        TransCatTotals.Add( cat, totalCategorySum );
                        highestTotal = totalCategorySum;
                    } else  //if equal add to the list
                        if ( totalCategorySum == highestTotal ) {
                            TransCatTotals.Add( cat, totalCategorySum );
                        }
                }
            }
            return TransCatTotals;
        }
        public static decimal GetTotalIncome() {
            decimal totalIncome = ( from trans in Transactions
                                    where trans.Catagory == TransactionCatagory.Income
                                    select trans ).Sum( trans => trans.Amount );
            return totalIncome;
        }
        public static decimal GetTotalExpense() {
            decimal totalExpense = ( from trans in Transactions
                                     where trans.Catagory != TransactionCatagory.Income
                                     select trans ).Sum( trans => trans.Amount );
            return totalExpense;
        }
        /// <summary>
        /// Reports And Summary Menu for making choices. Returns a string for the State Logic to decide. No validation on this end, except not null.
        /// </summary>
        /// <returns>String of the users input, unvalidated.</returns>
        private static void ViewReportAndSummary() {
            Console.Clear();
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_ReportsAndSummary ]} ------------", colorByGroup [ ColorGroup.MenuHeadings ] );
            Console.WriteLine();
            //Collect total expenses from catagories
            Dictionary<TransactionCatagory, decimal> TransCatTotals = GetTransactionCategoryTotals();



            //collect total income, expense and get the balance

            DateOnly earliestDate = Transactions.Min( t => t.Date );
            decimal totalIncome = GetTotalIncome();
            decimal totalExpense = GetTotalExpense();

            decimal currentBalance = totalIncome - totalExpense;


            Console.WriteLine( $"Account summary from {earliestDate.ToString( "dd/MMM/yyyy" )} to {DateOnly.FromDateTime( DateTime.Today ).ToString( "dd/MMM/yyyy" )} " );
            Console.WriteLine( "" );
            Console.WriteLine( $"Total income:\t\t{totalIncome.ToString( "C" )}" );
            Console.WriteLine( "" );
            Console.Write( $"Total expenses:\t\t" );
            ColorConsole.WriteLine( $"({totalExpense.ToString( "C" )})", ConsoleColor.Red );
            Console.WriteLine( "" );
            Console.Write( $"Total balance is:\t" );
            if ( currentBalance < 0 ) {
                ColorConsole.WriteLine( $"{currentBalance.ToString( "C" )}", ConsoleColor.Red );
            } else {
                Console.WriteLine( $"{currentBalance.ToString( "C" )}" );
            }
            Console.WriteLine( "" );
            Console.Write( $"Highest expense categorie(s): " );

            for ( int i = 0; i < TransCatTotals.Count; i++ ) {
                Console.Write( TransCatTotals.ElementAt( i ).Key );
                Console.Write( ", " );

            }
            Console.WriteLine( $"  at a cost of: {TransCatTotals.Last().Value.ToString( "C" )}" );


            return;
        }
        private static void XmlAccountSummary() {
            List<IXLWorksheet> Worksheets = new();
            using ( XLWorkbook workbook = new() ) {
                Worksheets.Add( workbook.AddWorksheet( "Account Summary" ) );

                if ( !workbook.TryGetWorksheet( "Account Summary", out var ws ) ) {
                    Console.WriteLine( "Could not find worksheet" );
                }



                const string ExcelAccountingFormat = "_([$$-en-US]* #,##0.00_);_([$$-en-US]* (#,##0.00);_([$$-en-US]* \"-\"??_);_(@_)";

                ws.Cell( "C1" ).Value = "Account Summary!";
                // Set style through property
                ws.Cell( "C1" ).Style
                    .Font.SetFontSize( 20 )
                    .Font.SetFontName( "Congenial UltraLight" )
                    .Fill.SetBackgroundColor( XLColor.WhiteSmoke );
                int ShiftUnderRulerDwonBy = 0;
                Dictionary<TransactionCatagory, decimal> TransCatTotals = GetTransactionCategoryTotals();
                Dictionary<TransactionCatagory, IXLRange> HighestCatsRanges = new();
                for ( int i = 0; i < TransCatTotals.Count; i++ ) {

                    //Console.Write( TransCatTotals.ElementAt( i ).Key );
                    //Console.Write( ", " );
                    HighestCatsRanges.Add( TransCatTotals.ElementAt( i ).Key, ws.Range( $"F{11 + i}:I{11 + i}" ) );
                    IXLRange item = HighestCatsRanges [ TransCatTotals.ElementAt( i ).Key ];
                    item.Merge();
                    item.Style.Font.FontColor = XLColor.Red;
                    item.Value = TransCatTotals.ElementAt( i ).Key.ToString();
                    item.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Center );
                    ShiftUnderRulerDwonBy = i;

                }
                ShiftUnderRulerDwonBy = 3;
                var xmlHeader = ws.Range( "C1:H3" );
                var xmlGreeting = ws.Range( "A5:J7" );
                var xmlIncome = ws.Range( "A9:B9" );
                var xmlIncomeArea = ws.Range( "C9:D9" );
                var xmlExpenses = ws.Range( "A11:B11" );
                var xmlExpensesArea = ws.Range( "C11:D11" );
                var xmlBalance = ws.Range( "A13:B13" );
                var xmlBalanceArea = ws.Range( "C13:D13" );
                var xmlHighestCategoryHeader = ws.Range( "F9:I9" );
                var xmlHorizontalRule1 = ws.Range( $"A{12 + ShiftUnderRulerDwonBy}:J{12 + ShiftUnderRulerDwonBy}" );
                var xmlAccountRecomendationHeading = ws.Range( $"D{14 + ShiftUnderRulerDwonBy}:G{14 + ShiftUnderRulerDwonBy}" );
                var xmlAccountRecomendationBody = ws.Range( $"B{16 + ShiftUnderRulerDwonBy}:I{18 + ShiftUnderRulerDwonBy}" );


                decimal totalIncome = GetTotalIncome();
                decimal totalExpense = GetTotalExpense();

                decimal currentBalance = totalIncome - totalExpense;


                xmlHeader.Merge();

                xmlGreeting.Merge();
                xmlGreeting.Value = "Thank you for using our program, I hope you enjoy this breif summary about your account. You will find more detials in another workbook which will give you some account summeies for some of the recent weeks";
                xmlGreeting.Cells().Style.Alignment.SetWrapText( true );
                xmlHeader.Style.Border.OutsideBorder = XLBorderStyleValues.Thick;

                xmlIncome.Merge();
                xmlIncome.Value = "Income: ";
                xmlIncome.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Right );
                xmlIncome.Style.Font.Bold = true;

                xmlIncomeArea.Merge();
                xmlIncomeArea.Style.Border.BottomBorder = XLBorderStyleValues.Medium;
                xmlIncomeArea.Style.Border.RightBorder = XLBorderStyleValues.Medium;
                xmlIncomeArea.Style.Fill.BackgroundColor = XLColor.WhiteSmoke;
                xmlIncomeArea.Value = totalIncome;
                xmlIncomeArea.Style.NumberFormat.SetFormat( ExcelAccountingFormat );



                xmlExpenses.Merge();
                xmlExpenses.Value = "Expenses: ";
                xmlExpenses.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Right );
                xmlExpenses.Style.Font.Bold = true;


                xmlExpensesArea.Merge();
                xmlExpensesArea.Style.Border.BottomBorder = XLBorderStyleValues.Medium;
                xmlExpensesArea.Style.Border.RightBorder = XLBorderStyleValues.Medium;
                xmlExpensesArea.Style.Fill.BackgroundColor = XLColor.WhiteSmoke;
                xmlExpensesArea.Value = totalExpense;
                xmlExpensesArea.Style.NumberFormat.SetFormat( ExcelAccountingFormat );

                xmlBalance.Merge();
                xmlBalance.Value = "Balance: ";
                xmlBalance.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Right );
                xmlBalance.Style.Font.Bold = true;

                xmlBalanceArea.Merge();
                xmlBalanceArea.Style.Border.BottomBorder = XLBorderStyleValues.Medium;
                xmlBalanceArea.Style.Border.RightBorder = XLBorderStyleValues.Medium;
                xmlBalanceArea.Style.Fill.BackgroundColor = XLColor.WhiteSmoke;
                xmlBalanceArea.Value = currentBalance;
                xmlBalanceArea.Style.NumberFormat.SetFormat( ExcelAccountingFormat );

                xmlHighestCategoryHeader.Merge();
                xmlHighestCategoryHeader.Value = "Highest Transaction Catagories";

                xmlHighestCategoryHeader.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Center );
                xmlHighestCategoryHeader.Style.Font.Bold = true;


                xmlHorizontalRule1.Merge();
                xmlHorizontalRule1.Style.Border.BottomBorder = XLBorderStyleValues.Medium;


                xmlAccountRecomendationHeading.Merge();
                xmlAccountRecomendationHeading.Value = "Bank Reccomendations";
                xmlAccountRecomendationHeading.Style.Border.OutsideBorder = XLBorderStyleValues.Medium;
                xmlAccountRecomendationHeading.Style.Fill.BackgroundColor = XLColor.Yellow;
                xmlAccountRecomendationHeading.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Center );
                xmlAccountRecomendationHeading.Style.Alignment.SetVertical( XLAlignmentVerticalValues.Center );
                string reccomendation = "";
                if ( currentBalance > 10000 ) {
                    reccomendation = "Based on your income we can offer you a high interest managed RRSP to maxamize your gains. with 7% Y.O.Y. gaurunteed.";
                } else if ( currentBalance > 5000 ) {
                    reccomendation = "Based on your income we can offer you a medium interest managed RRSP to maxamize your gains. with 4% Y.O.Y. gaurunteed.";
                }
                if ( currentBalance > 1000 ) {
                    reccomendation = "Based on your income we suggest a savings account to start saving an emergency fund.";
                }

                if ( currentBalance > -1000 ) {
                    reccomendation = "Based on your income we can offer you a high interest Credit Card, with 22% Apr. and first month free interest.";
                }
                if ( currentBalance > -5000 ) {
                    reccomendation = "Based on your income we can offer you a medium interest Credit Card, with 12% Apr. and three months free interest.";
                }
                reccomendation = currentBalance > -10000
                    ? "Based on your income we are offering free credit counciling, and the reccomendation of securing more stable and higher income."
                    : "This is really really bad, we may need to forclose all of your assets! Please come into our office right away, we are sending a cour appointed police officer to assist you.";

                xmlAccountRecomendationBody.Merge();

                xmlAccountRecomendationBody.Value = reccomendation;
                xmlAccountRecomendationBody.Cells().Style.Alignment.SetWrapText( true );
                xmlAccountRecomendationBody.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Left );
                xmlAccountRecomendationBody.Style.Alignment.SetVertical( XLAlignmentVerticalValues.Top );

                xmlHeader.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Center );
                xmlHeader.Style.Alignment.SetVertical( XLAlignmentVerticalValues.Center );

                DateOnly dateRange = DateOnly.FromDateTime( DateTime.Today );

                for ( int i = 1; i < 12; i++ ) {



                    List<Transaction> orderedTrans = ( from trans in Transactions
                                                       where trans.Date.Year == dateRange.Year
                                                       && trans.Date.Month == dateRange.Month
                                                       orderby trans.Date descending
                                                       select trans ).ToList();

                    IXLWorksheet sumSheeti = workbook.AddWorksheet( $"{dateRange.Month}, {dateRange.Year}" );
                    if ( orderedTrans.Count > 0 ) {
                        sumSheeti.Column( 1 ).Width = 10.36;
                        sumSheeti.Column( 2 ).Width = 17;
                        sumSheeti.Column( 3 ).Width = 43.36;
                        sumSheeti.Column( 4 ).Width = 15.55;
                        sumSheeti.Row( 1 ).Style.Font.Bold = true;
                        var date = sumSheeti.Cell( 1, 1 ).Value = "Date";

                        var transCat = sumSheeti.Cell( 1, 2 );
                        var description = sumSheeti.Cell( 1, 3 );
                        var amount = sumSheeti.Cell( 1, 4 );


                        transCat.Value = "Category";
                        description.Value = "Description";
                        amount.Value = "Amount";

                        int index = 2;


                        foreach ( Transaction trans in orderedTrans ) {

                            var transDateCells = sumSheeti.Cell( index, 1 );
                            transDateCells.Value = trans.Date.ToString();
                            transDateCells.Style.NumberFormat.Format = "mm/dd/yyyy";


                            var transCatCells = sumSheeti.Cell( index, 2 );
                            transCatCells.Value = trans.Catagory.ToString();

                            var transDescCells = sumSheeti.Cell( index, 3 );
                            transDescCells.Value = trans.Description;

                            var transAmountCells = sumSheeti.Cell( index, 4 );
                            transAmountCells.Value = trans.Catagory != TransactionCatagory.Income ? ( XLCellValue ) ( trans.Amount * -1 ) : ( XLCellValue ) trans.Amount;
                            transAmountCells.Style.NumberFormat.Format = ExcelAccountingFormat;


                            index++;



                        }
                        var lastRow = sumSheeti.LastRowUsed().RowNumber();
                        var lastCol = sumSheeti.LastColumnUsed().ColumnNumber();

                        var range = sumSheeti.Range( 1, 1, lastRow, lastCol );
                        var table = range.CreateTable();
                    } else {

                        var noInfo = sumSheeti.Range( "B3:I4" );
                        noInfo.Merge();
                        noInfo.Value = "Sorry, you currently do not have any transactions for this Month. This document is provided for your records.";
                        noInfo.Style.Alignment.SetHorizontal( XLAlignmentHorizontalValues.Center );

                        noInfo.Style.Alignment.SetVertical( XLAlignmentVerticalValues.Center );

                        noInfo.Style.Border.OutsideBorder = XLBorderStyleValues.Medium;

                        noInfo.Style.Fill.BackgroundColor = XLColor.WhiteSmoke;
                        noInfo.Cells().Style.Alignment.SetWrapText( true );

                    }
                    dateRange = dateRange.AddMonths( -1 );


                }




                int fileI = 0;
                string suf = "";
                while ( true ) {
                    try {
                        workbook.SaveAs( $"accountSummary{suf}.xlsx" );

                    } catch ( IOException ) {
                        fileI++;
                        if ( fileI < 20 ) {
                            suf = fileI.ToString();
                            continue;
                        } else {
                            Console.WriteLine( "The file could not be accessed. Please make sure it is not open in another program and that this application has permission to write to the selected folder." );
                            AnyKeyToContinue();
                        }

                    }
                    break;

                }
            }
        }
        private static void MonthlyReport() {
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_ReportsAndSummary ]} (Montly Report)  ------------", colorByGroup [ ColorGroup.MenuHeadings ] );

            Console.ReadKey();


        }
        private static bool GetAmount( ref decimal amt, bool allowInputZero = false ) {
            //Ask enter amount

            while ( true ) {
                ColorConsole.Write( outputMessage [ MessageEnum.SystemInstructionsAbort ], colorByGroup [ ColorGroup.SystemInstructions ] );
                ColorConsole.Write( $" {outputMessage [ MessageEnum.SystemInstructionsInputIncomeAmount ]} : " );
                string incomeInput = ColorConsole.ReadLine();
                // user typed exit in native language, returning
                if ( incomeInput == outputMessage [ MessageEnum.LabelExit ] ) {
                    Console.Clear();
                    ColorConsole.WriteLine( outputMessage [ MessageEnum.TransMgnt_Return ] );
                    return true;
                }
                if ( !decimal.TryParse( incomeInput, out amt ) || allowInputZero ? amt < 0 : amt <= 0 ) {
                    ColorConsole.Write( outputMessage [ MessageEnum.SystemMenuBadInput ], colorByGroup [ ColorGroup.SystemInstructions ] );
                    ColorConsole.WriteLine( $" {outputMessage [ MessageEnum.SystemMenuBadAmount ]}", colorByGroup [ ColorGroup.SystemError ] );
                } else {
                    if ( amt > 999999999999.9m ) {
                        ColorConsole.Write( outputMessage [ MessageEnum.SystemMenuBadInput ], colorByGroup [ ColorGroup.SystemInstructions ] );
                        ColorConsole.WriteLine( "A single transaction can't have an amount over one trillion, please break up into smaller transactions", colorByGroup [ ColorGroup.SystemInstructions ] );
                    }

                }
                return false;
            }

        }
        private static int GetTransactionCategoryLongestLength() {
            foreach ( string cat in Enum.GetNames( typeof( TransactionCatagory ) ) ) {
                int catLen = cat.Length;
                if ( transactionCategoryLongestSize < catLen )
                    transactionCategoryLongestSize = catLen;
            }
            return transactionCategoryLongestSize;
        }
        private static bool GetCategory( ref TransactionCatagory cat ) {
            //Ask category if Type expense
            ColorConsole.WriteLine( "\n----- Expense Category -----", MenuHeadings );

            foreach ( var item in Enum.GetValues<TransactionCatagory>() ) {
                if ( item != 0 )
                    Console.WriteLine( ( int ) item + ". " + item );
            }

            while ( true ) {

                ColorConsole.Write( outputMessage [ MessageEnum.SystemInstructionsAbort ], colorByGroup [ ColorGroup.SystemInstructions ] );
                Console.Write( "Please enter an associated category number : " );
                string enumber = Console.ReadLine();
                // user typed exit in native language, returning
                if ( enumber == outputMessage [ MessageEnum.LabelExit ] ) {
                    Console.Clear();
                    ColorConsole.WriteLine( outputMessage [ MessageEnum.TransMgnt_Return ] );
                    return true;
                }
                if ( !Enum.TryParse<TransactionCatagory>( enumber, out cat ) || cat == 0 ) {
                    Console.WriteLine( "Wrong Catagory, please make sure you put in the proper number" );
                }
                return false;
            }
        }

        /// <summary>
        /// Overloaded to provide two refrences for swaping plaves
        /// </summary>
        /// <param name="date"></param>
        /// <param name="comparedate"></param>
        private static bool GetDate( ref DateOnly date, ref DateOnly compareDate ) {
            while ( true ) {
                if ( GetDate( ref date ) ) {
                    return true;
                }

                if ( date == compareDate ) {
                    Console.WriteLine( "These are the same dates! You will have to enter a different date" );
                    continue;
                } else if ( date < compareDate ) {
                    //Swamping dates to keep the low ranges in order, may not be needed!
                    DateOnly swapDate = date;
                    date = compareDate;
                    compareDate = swapDate;
                }
                Console.WriteLine( $"Searching list for dates between {date.ToString( dateFormatOut.Item1 )} and {compareDate.ToString( dateFormatOut.Item1 )}  " );
                return false;
            }
        }

        private static bool GetDate( ref DateOnly date ) {
            while ( true ) {
                ColorConsole.Write( outputMessage [ MessageEnum.SystemInstructionsAbort ], colorByGroup [ ColorGroup.SystemInstructions ] );
                ColorConsole.Write( $" {outputMessage [ MessageEnum.SystemInstructionsEnterDate ]} {outputMessage [ MessageEnum.SystemMenuDateFormat ]} : " );
                string DateInput = ColorConsole.ReadLine();
                // user typed exit in native language, returning
                if ( DateInput == outputMessage [ MessageEnum.LabelExit ] ) {
                    Console.Clear();
                    ColorConsole.WriteLine( outputMessage [ MessageEnum.TransMgnt_Return ] );

                    return true;
                }
                //uses a tuple to get the format type accociated stirng, storing the space used by MM, MMM, or MMMM (max is 9 'september')
                if ( !DateOnly.TryParseExact( DateInput, dateFormatDictionary [ DateFormatEnum.NumberMonth ].Item1, out date ) ) {

                    ColorConsole.Write( outputMessage [ MessageEnum.SystemMenuBadInput ], colorByGroup [ ColorGroup.SystemInstructions ] );
                    ColorConsole.WriteLine( $" {outputMessage [ MessageEnum.SystemMenuBadDate ]} {outputMessage [ MessageEnum.SystemMenuDateFormat ]}" );
                }
                break;
            }
            return false;
        }
        public static void AnyKeyToContinue( bool ClearAfter = false, bool BypassMsg = false, bool WriteLine = true ) {
            if ( !BypassMsg ) {
                if ( WriteLine )
                    Console.WriteLine( outputMessage [ MessageEnum.PressAnyKeyToContinue ] );
                else
                    Console.Write( outputMessage [ MessageEnum.PressAnyKeyToContinue ] );
            }

            Console.CursorVisible = false;
            Console.ReadKey();
            Console.CursorVisible = true;
            if ( ClearAfter ) {
                Console.Clear();
            }
        }
    }
}
