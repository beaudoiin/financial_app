﻿namespace Assignment1 {
    class outputMethods {
        /// <summary>
        /// Print passed message in Red with a black background and then set it back to the colour it was prior.
        /// </summary>
        /// <param name="msg">String to output to WriteLine</param>
        public static void warning( string msg ) {
            ConsoleColor [ ] revert = { Console.ForegroundColor, Console.BackgroundColor };
            Console.ForegroundColor = ConsoleColor.Red;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine( msg );
            Console.ForegroundColor = revert [ 0 ];
            Console.BackgroundColor = revert [ 1 ];
        }
    }
}
