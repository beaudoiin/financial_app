﻿namespace Assignment1 {
    public enum TransactionCatagory {
        Unspecified,
        Housing,
        Groceries,
        Transportation,
        Utilities,
        Restaurants,
        Insurance,
        Debt,
        Entertainment,
        Healthcare,
        Income,
        Transfers,
        Fees
    }
    public class Transaction {
        public DateOnly Date {
            get; set;
        }
        public TransactionCatagory Catagory {
            get; set;
        }

        public decimal Amount {

            get; set;
        }
        public string Description {
            get; set;
        }
        public Transaction( DateOnly Date, decimal Amount, string Description, TransactionCatagory category = 0 ) {

            this.Date = Date;
            this.Amount = Math.Round( Amount, 2 );
            this.Description = Description;
            this.Catagory = category;
        }
    }

}