﻿using System.Xml;
using System.Xml.Linq;
using static Assignment1.outputMethods;
using static Assignment1.Program;

namespace Assignment1 {
    class xmlMethods {
        /// <summary>
        /// Gets the messages from a loaded xml file and distributes them to the outputMessages Dictionary based on specified by string language, based on ISO 639 language code.
        /// </summary>
        /// <param name="outputdictionary">refrence of dictionary for Adding messages too.</param>
        /// <param name="xmlfile">String of xmlfile</param>
        public static void GetMessages( ref Dictionary<MessageEnum, string> outputdictionary, in string xmlfile, in Dictionary<MessageEnum, string> defualtEnglishMessages ) {
            string fallthrough = "Reverting to default English Dictionary";
            try {
                var xdoc = XDocument.Load( xmlfile );
                //returns null if non exitst and null is used to gaurd reading properties that are null by just flowing out of try and returning.
                var items = xdoc?.Root?.Descendants( language )?.Descendants( "item" )?.Select( x => new { key = x.Attribute( "key" )?.Value, Value = x.Element( "message" )?.Value } );
                if ( items is not null ) {
                    foreach ( var item in items ) {
                        if ( item is not null ) {
                            //Consider using these debugs to help spot if your XML and Enum are not matched up
                            //Console.WriteLine( item.key );
                            //Console.WriteLine( "enumKey Test: " + item.key );
                            if ( Enum.TryParse<MessageEnum>( item.key, true, out MessageEnum enumKey ) && item.Value is not null ) {
                                outputdictionary.Add( enumKey, item.Value );
                                //Consider using these debugs to help spot if your XML and Enum are not matched up
                                //Console.WriteLine( "Added : " + outputdictionary [ enumKey ]
                                //    + " : Added" );
                            } else {

                                outputdictionary.Add( enumKey, defualtEnglishMessages [ enumKey ] );
                            }
                        }
                    }
                }

            } catch ( XmlException ) { warning( "Xml not formated properly! " + fallthrough ); outputdictionary = defualtEnglishMessages; } catch ( DirectoryNotFoundException ) { warning( "Directory not found! " + fallthrough ); outputdictionary = defualtEnglishMessages; } catch ( UnauthorizedAccessException ) { warning( "Not authorized to access xml file at location! " + fallthrough ); outputdictionary = defualtEnglishMessages; } catch ( ArgumentException ) { warning( "File passed not expected format! " + fallthrough ); outputdictionary = defualtEnglishMessages; } catch ( FileNotFoundException ) { warning( "File not found! " + fallthrough ); outputdictionary = defualtEnglishMessages; }
        }
    }
}
