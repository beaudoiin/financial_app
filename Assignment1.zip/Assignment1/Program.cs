﻿using static Assignment1.xmlMethods;

namespace Assignment1 {
    class Program {

        public static List<Transaction> Transactions = new();

        const string xmlfile = @"C:\Users\beaud\source\repos\Assignment1\Assignment1\language\lang.xml";

        //Add as defualt hardcoded incase an element is missign from the xml dictionary or the dictionary cant be loaded.
        //Ensure at deployment these elements match the default english in the xml.
        public static Dictionary<MessageEnum, string> defaultEnglishMessages = new() {
    // instructions
    { MessageEnum.SystemInstructionsAnyKey, "Press any key to Acknowledge" },
    { MessageEnum.SystemMenuBadInput, "Bad Input! Try again!" },
    { MessageEnum.SystemMenuBadAmount, "Amount must be greater than zero and cannot be blank." },
    { MessageEnum.SystemInstructionsAbort, "(Type exit to abort)" },
    { MessageEnum.SystemInstructionsInputIncomeAmount, "Please enter an income Amount as a positive number" },
    { MessageEnum.SystemInstructionsInputTransDescritption, "Please enter a description of the transaction" },
    { MessageEnum.SystemInstructionsEnterDate, "Please enter the transaction date in the following format:" },
    { MessageEnum.SystemMenuBadDate, "Please use the proper date convention:" },
    { MessageEnum.SystemMenuDateFormat, "dd/MM/yyyy" },
    { MessageEnum.SystemEmptyOrSpaces, "Can't be empty or spaces only!" },
    { MessageEnum.PressAnyKeyToContinue, "Press Any Key To Continue" },

    // labels
    { MessageEnum.labelExit, "exit" },
    { MessageEnum.labelEnter, "Enter" },
    { MessageEnum.labelOr, "or" },
    { MessageEnum.labelStarting, "Starting" },
    { MessageEnum.labelDate, "Date" },
    { MessageEnum.labelAmount, "Amount" },
    { MessageEnum.labelDescription, "Description" },
    { MessageEnum.AddIncomeTransaction_Label, "Add Income Transaction" },

    // general options
    { MessageEnum.Menu_Return, "Return to main menu" },

    // main menu
    { MessageEnum.MainMenu_Label, "Main menu" },
    { MessageEnum.MainMenu_TransactionManagement, "Transaction management" },
    { MessageEnum.MainMenu_BudgetTools, "Budget Tools" },
    { MessageEnum.MainMenu_ReportsAndSummary, "Reports And Summary" },

    // transaction management submenu
    { MessageEnum.TransMgnt_AddIncomeTransaction, "Add income transaction" },
    { MessageEnum.TransMgnt_Return, "Returning to transactional management" },
    { MessageEnum.TransMgnt_AddExpenseTransaction, "Add expense transaction" },
    { MessageEnum.TransMgnt_ViewAllTransactions, "View all transactions" },
    { MessageEnum.TransMgnt_SearchTransactions, "Search for a transaction" },
    { MessageEnum.TransMgnt_TransactionAdded, "Congratulations, Transaction added!" },

    // budget tools submenu
    { MessageEnum.BudgetTools_SetMonlyBudget, "Set monthly budget" },
    { MessageEnum.BudgetTools_UpdateBudgetCateg, "Update budget category" },
    { MessageEnum.BudgetTools_CheckRemainBudget, "Check remaining budget" },
    { MessageEnum.BudgetTools_Warning80PercentOverBudget, "Warning! You are more then 80Percent over your budget" },

    // reports & summary submenu
    { MessageEnum.ReportAndSum_TotalIncome, "Total income" },
    { MessageEnum.ReportAndSum_TotalExpense, "Total expense" },
    { MessageEnum.BudgetTools_CurrentBalance, "Check remaining budget" },
    { MessageEnum.ReportAndSum_MonthlySummary, "Monthly summary" },
    { MessageEnum.ReportAndSum_HighestExpenseCategory, "Highest expense category" }
};
        /// <summary>
        /// Enum for pointing to colors based on groups in the dictionary colorByGroup.
        /// </summary>
        public enum ColorGroup {
            SystemExit,
            SystemError,
            SystemInstructions,
            SystemInstructionsAnyKey,
            MenuHeadings,
            MenuItems,
            Success
        }
        public static bool optionsClearAfterAwknoledge = true;
        /// <summary>
        /// Dictionary for grouped colors. ColorGroup enum As Key and value is an 2 length array, Foreground ConsoleColor, and Background ConsoleColor.
        /// </summary>
        public static Dictionary<ColorGroup, ConsoleColor [ ]> colorByGroup = new() {
            {ColorGroup.SystemExit, [ConsoleColor.Red, ConsoleColor.Black ] },
            {ColorGroup.SystemError, [ConsoleColor.Red, ConsoleColor.White ] },
            {ColorGroup.SystemInstructions, [ConsoleColor.Cyan, ConsoleColor.Black ] },
            {ColorGroup.SystemInstructionsAnyKey, [ConsoleColor.Gray, ConsoleColor.Black ] },
            {ColorGroup.MenuHeadings, [ConsoleColor.Cyan, ConsoleColor.Black ] },
            {ColorGroup.MenuItems, [ConsoleColor.Green, ConsoleColor.Black ] },
            {ColorGroup.Success, [ConsoleColor.Black, ConsoleColor.Yellow ] }
        };
        public static ConsoleColor [ ] MenuHeadings = colorByGroup [ ColorGroup.MenuHeadings ];
        public static ConsoleColor [ ] MenuItemColor = colorByGroup [ ColorGroup.MenuItems ];

        /// <summary>
        ///Provides index keys for outputMessage Dictionary. Assisst in outputting the proper WriteLine messages.
        ///Ensure these match the keys in xml for each language.
        /// </summary>
        public enum MessageEnum {

            //Instructions
            SystemInstructionsAnyKey,
            SystemMenuBadInput,
            SystemInstructionsAbort,
            SystemInstructionsInputIncomeAmount,
            SystemInstructionsInputTransDescritption,
            SystemInstructionsEnterDate,
            SystemMenuBadDate,
            SystemMenuDateFormat,
            SystemEmptyOrSpaces,
            PressAnyKeyToContinue,

            //warning
            SystemMenuBadAmount,

            //labels
            labelExit,
            labelEnter,
            labelOr,
            labelStarting,
            labelDate,
            labelAmount,
            labelDescription,
            AddIncomeTransaction_Label,

            //General options
            Menu_Return,

            //Menu uoptions
            MainMenu_Label,
            MainMenu_TransactionManagement,
            MainMenu_BudgetTools,
            MainMenu_ReportsAndSummary,

            //Transaction management submenu
            TransMgnt_AddIncomeTransaction,
            TransMgnt_AddExpenseTransaction,
            TransMgnt_ViewAllTransactions,
            TransMgnt_SearchTransactions,
            TransMgnt_Return,
            TransMgnt_TransactionAdded,

            //Budget Tools SubMenu 
            BudgetTools_SetMonlyBudget,
            BudgetTools_UpdateBudgetCateg,
            BudgetTools_CheckRemainBudget,
            BudgetTools_Warning80PercentOverBudget,

            //Reports & Summary SubMenu
            ReportAndSum_TotalIncome,
            ReportAndSum_TotalExpense,
            BudgetTools_CurrentBalance,
            ReportAndSum_MonthlySummary,
            ReportAndSum_HighestExpenseCategory

        }
        enum IncomeOrExpense {
            Income,
            Expense
        }
        //Creates an empty outputMessages 
        public static Dictionary<MessageEnum, string> outputMessage = new();

        /// <summary>
        /// ISO 639 language code to specify language to load from xml.
        /// </summary>
        public static string language = "en"; //why does this have to be static to be used in XDocument?
        static void Main( string [ ] args ) {
            //To display special letters in polish and french
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;
            Console.CursorVisible = false;
            //passed bby refrence to allow manipulating outputMessages
            GetMessages( ref outputMessage, xmlfile, defaultEnglishMessages );
            ColorConsole.WriteLine( outputMessage [ MessageEnum.labelStarting ], WaitForAcknowledgment: true );

            //Create customer for testing

            //Main Menu Logic and Input Validation
            while ( true ) {


                switch ( MainMenuChoice() ) {

                    case "1":
                        TransactionManagement();
                        break;
                    case "2":
                        //BudgetTools()
                        break;
                    case "3":
                        //ReportsAndSummary();
                        break;
                    case "4":
                        ColorConsole.WriteLine( outputMessage [ MessageEnum.labelExit ], colorByGroup [ ColorGroup.SystemExit ], ColorAfterFg: ConsoleColor.White, ColorAfterBg: ConsoleColor.Black, WaitForAcknowledgment: true );
                        Environment.Exit( 0 );
                        break;
                    default:
                        ColorConsole.WriteLine( outputMessage [ MessageEnum.SystemMenuBadInput ], colorByGroup [ ColorGroup.SystemError ], WaitForAcknowledgment: true );

                        break;

                }
            }
        }
        /// <summary>
        /// Will need to return something probably, dontClearOnDraw Allows for you to leave the last screen showing. Good for allowing a lingering return message.
        /// </summary>
        private static void TransactionManagement( bool dontClearOnDraw = false ) {
            while ( true ) {
                //Clear the screen weather returning or from a different menu (Main Menu)
                if ( !dontClearOnDraw )
                    Console.Clear();
                switch ( TransactionManagementMenuChoice() ) {
                    //Add Income
                    case "1":
                        dontClearOnDraw = AddIncomeExpenseTransaction( IncomeOrExpense.Income );
                        break;
                    case "2":
                        dontClearOnDraw = AddIncomeExpenseTransaction( IncomeOrExpense.Expense );
                        break;
                    case "3":
                        //ReportsAndSummary();
                        break;
                    case "4":
                        ColorConsole.WriteLine( outputMessage [ MessageEnum.labelExit ], colorByGroup [ ColorGroup.SystemExit ], ColorAfterFg: ConsoleColor.White, ColorAfterBg: ConsoleColor.Black, WaitForAcknowledgment: true );
                        Environment.Exit( 0 );
                        break;
                    default:
                        ColorConsole.WriteLine( outputMessage [ MessageEnum.SystemMenuBadInput ], colorByGroup [ ColorGroup.SystemError ], WaitForAcknowledgment: true );

                        break;

                }
            }
        }
        /// <summary>
        /// Will need to return something probably, dontClearOnDraw Allows for you to leave the last screen showing. Good for allowing a lingering return message.
        /// </summary>
        private static bool AddIncomeExpenseTransaction( IncomeOrExpense type ) {
            string transType = Enum.GetName<IncomeOrExpense>( type );

            Console.Clear();
            decimal amount;
            string dateformat = "dd/MM/yyyy";
            DateOnly date = new();
            string descriptionInput;
            string incomeInput;
            TransactionCatagory cat = new();

            ///Prints an exit message

            //heading
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.AddIncomeTransaction_Label ]} ------------", MenuHeadings );
            //Ask category if Type expense
            ColorConsole.WriteLine( "\n----- Expense Category -----", MenuHeadings );
            if ( type == IncomeOrExpense.Expense ) {
                foreach ( var item in Enum.GetValues<TransactionCatagory>() ) {
                    if ( item != 0 )
                        Console.WriteLine( ( int ) item + ". " + item );
                }

                while ( true ) {

                    ColorConsole.Write( outputMessage [ MessageEnum.SystemInstructionsAbort ], colorByGroup [ ColorGroup.SystemInstructions ] );
                    Console.Write( "Please enter an associated category number : " );
                    string enumber = Console.ReadLine();
                    // user typed exit in native language, returning
                    if ( enumber == outputMessage [ MessageEnum.labelExit ] ) {
                        Console.Clear();
                        ColorConsole.WriteLine( outputMessage [ MessageEnum.TransMgnt_Return ] );
                        return true;
                    }
                    if ( !Enum.TryParse<TransactionCatagory>( enumber, out cat ) || cat == 0 ) {
                        Console.WriteLine( "Wrong Catagory, please make sure you put in the proper number" );
                    }
                    break;
                }
            }
            //Ask enter amount
            while ( true ) {
                ColorConsole.Write( outputMessage [ MessageEnum.SystemInstructionsAbort ], colorByGroup [ ColorGroup.SystemInstructions ] );
                ColorConsole.Write( $" {outputMessage [ MessageEnum.SystemInstructionsInputIncomeAmount ]} : " );
                incomeInput = ColorConsole.ReadLine();
                // user typed exit in native language, returning
                if ( incomeInput == outputMessage [ MessageEnum.labelExit ] ) {
                    Console.Clear();
                    ColorConsole.WriteLine( outputMessage [ MessageEnum.TransMgnt_Return ] );
                    return true;
                }
                if ( !decimal.TryParse( incomeInput, out amount ) || amount <= 0 ) {
                    ColorConsole.Write( outputMessage [ MessageEnum.SystemMenuBadInput ], colorByGroup [ ColorGroup.SystemInstructions ] );
                    ColorConsole.WriteLine( $" {outputMessage [ MessageEnum.SystemMenuBadAmount ]}", colorByGroup [ ColorGroup.SystemError ] );
                } else
                    break;
            }
            //Ask Description
            while ( true ) {
                ColorConsole.Write( outputMessage [ MessageEnum.SystemInstructionsAbort ], colorByGroup [ ColorGroup.SystemInstructions ] );
                ColorConsole.Write( $" {outputMessage [ MessageEnum.SystemInstructionsInputTransDescritption ]} : " );
                descriptionInput = ColorConsole.ReadLine();
                // user typed exit in native language, returning
                if ( descriptionInput == outputMessage [ MessageEnum.labelExit ] ) {
                    Console.Clear();
                    ColorConsole.WriteLine( outputMessage [ MessageEnum.TransMgnt_Return ] );
                    return true;
                }

                if ( string.IsNullOrWhiteSpace( descriptionInput ) ) {
                    ColorConsole.Write( outputMessage [ MessageEnum.SystemMenuBadInput ], colorByGroup [ ColorGroup.SystemInstructions ] );
                    ColorConsole.WriteLine( $" {outputMessage [ MessageEnum.SystemEmptyOrSpaces ]}" );
                } else
                    break;
            }
            //Ask Date
            while ( true ) {
                ColorConsole.Write( outputMessage [ MessageEnum.SystemInstructionsAbort ], colorByGroup [ ColorGroup.SystemInstructions ] );
                ColorConsole.Write( $" {outputMessage [ MessageEnum.SystemInstructionsEnterDate ]} {outputMessage [ MessageEnum.SystemMenuDateFormat ]} : " );
                string DateInput = ColorConsole.ReadLine();
                // user typed exit in native language, returning
                if ( DateInput == outputMessage [ MessageEnum.labelExit ] ) {
                    Console.Clear();
                    ColorConsole.WriteLine( outputMessage [ MessageEnum.TransMgnt_Return ] );

                    return true;
                }
                if ( !DateOnly.TryParseExact( DateInput, dateformat, out date ) && amount > 0 ) {

                    ColorConsole.Write( outputMessage [ MessageEnum.SystemMenuBadInput ], colorByGroup [ ColorGroup.SystemInstructions ] );
                    ColorConsole.WriteLine( $" {outputMessage [ MessageEnum.SystemMenuBadDate ]} {outputMessage [ MessageEnum.SystemMenuDateFormat ]}" );
                } else
                    break;
            }
            //create new transaction and display it, wait for user to confirm before going back to transaction management menu
            if ( type == IncomeOrExpense.Expense )
                Transactions.Add( new Transaction( date, amount, descriptionInput, cat ) );
            else
                Transactions.Add( new Transaction( date, amount, descriptionInput ) );
            Console.Clear();

            //Seperates labels and colors them based on systeminstructions Colors
            ColorConsole.WriteLine( $" {outputMessage [ MessageEnum.TransMgnt_TransactionAdded ]} : {transType} ", colorByGroup [ ColorGroup.Success ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.labelDate ]} : ", colorByGroup [ ColorGroup.SystemInstructions ] );
            Console.WriteLine( $"{Transactions.Last().Date}, " );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.labelAmount ]} : ", colorByGroup [ ColorGroup.SystemInstructions ] );
            Console.WriteLine( $"{Transactions.Last().Amount.ToString( "C" )}, " ); //formats as currency of the system.
            ColorConsole.Write( $"{outputMessage [ MessageEnum.labelDescription ]} : ", colorByGroup [ ColorGroup.SystemInstructions ] );
            ColorConsole.WriteLine( $"{Transactions.Last().Description}" );
            if ( type == IncomeOrExpense.Expense ) {
                ColorConsole.Write( $"Transaction Category : ", colorByGroup [ ColorGroup.SystemInstructions ] );
                if ( Transactions.Last().Catagory is not 0 ) {
                    ColorConsole.Write( $"{Enum.GetName<TransactionCatagory>( Transactions.Last().Catagory )}" );
                }
            }
            ColorConsole.Write( "", WaitForAcknowledgment: true );
            return true;

        }

        //Print Various Menu Options
        /// <summary>
        /// Main menu for making choices. Returns a string for the State Logic to decide. No validation on this end, except not null.
        /// </summary>
        /// <returns>String of the users input, unvalidated.</returns>
        private static string MainMenuChoice() {


            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_Label ]} ------------", MenuHeadings );
            ColorConsole.WriteLine( "\t1 - " + outputMessage [ MessageEnum.MainMenu_TransactionManagement ], MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t2 - " + outputMessage [ MessageEnum.MainMenu_BudgetTools ] );
            ColorConsole.WriteLine( "\t3 - " + outputMessage [ MessageEnum.MainMenu_ReportsAndSummary ] );
            ColorConsole.WriteLine( "\t4 - " + outputMessage [ MessageEnum.labelExit ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.labelEnter ]} 1, 2, 3, {outputMessage [ MessageEnum.labelOr ]} 4 : ", ConsoleColor.White );
            //will leave color as is next command in flow should reset the color to desired
            string return_str = ColorConsole.ReadLine( ConsoleColor.Yellow );
            return return_str;
        }
        /// <summary>
        /// Transaction Management Menu for making choices. Returns a string for the State Logic to decide. No validation on this end, except not null.
        /// </summary>
        /// <returns>String of the users input, unvalidated.</returns>
        private static string TransactionManagementMenuChoice() {
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_TransactionManagement ]} ------------", MenuHeadings );
            ColorConsole.WriteLine( "\t1 - " + outputMessage [ MessageEnum.TransMgnt_AddIncomeTransaction ], MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t2 - " + outputMessage [ MessageEnum.TransMgnt_AddExpenseTransaction ] );
            ColorConsole.WriteLine( "\t3 - " + outputMessage [ MessageEnum.TransMgnt_ViewAllTransactions ] );
            ColorConsole.WriteLine( "\t4 - " + outputMessage [ MessageEnum.TransMgnt_SearchTransactions ] );
            ColorConsole.WriteLine( "\t5 - " + outputMessage [ MessageEnum.Menu_Return ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.labelEnter ]} 1, 2, 3, 4 {outputMessage [ MessageEnum.labelOr ]} 5 : ", ConsoleColor.White );
            //will leave color as is next command in flow should reset the color to desired
            string return_str = ColorConsole.ReadLine( ConsoleColor.Yellow );
            return return_str;
        }

        /// <summary>
        /// Budget Tools Menu for making choices. Returns a string for the State Logic to decide. No validation on this end, except not null.
        /// </summary>
        /// <returns>String of the users input, unvalidated.</returns>
        private static string BudgetToolsMenuChoice() {

            ConsoleColor [ ] MenuHeadings = colorByGroup [ ColorGroup.MenuHeadings ];
            ConsoleColor [ ] MenuItemColor = colorByGroup [ ColorGroup.MenuItems ];
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_BudgetTools ]} ------------", MenuHeadings );
            ColorConsole.WriteLine( "\t1 - " + outputMessage [ MessageEnum.BudgetTools_SetMonlyBudget ], MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t2 - " + outputMessage [ MessageEnum.BudgetTools_UpdateBudgetCateg ] );
            ColorConsole.WriteLine( "\t3 - " + outputMessage [ MessageEnum.BudgetTools_CheckRemainBudget ] );
            ColorConsole.WriteLine( "\t4 - " + outputMessage [ MessageEnum.Menu_Return ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.labelEnter ]} 1, 2, 3, {outputMessage [ MessageEnum.labelOr ]} 4 : ", ConsoleColor.White );
            //will leave color as is next command in flow should reset the color to desired
            string return_str = ColorConsole.ReadLine( ConsoleColor.Yellow );
            return return_str;
        }

        /// <summary>
        /// Reports And Summary Menu for making choices. Returns a string for the State Logic to decide. No validation on this end, except not null.
        /// </summary>
        /// <returns>String of the users input, unvalidated.</returns>
        private static string ReportsAndSummaryMenuChoice() {

            ConsoleColor [ ] MenuHeadings = colorByGroup [ ColorGroup.MenuHeadings ];
            ConsoleColor [ ] MenuItemColor = colorByGroup [ ColorGroup.MenuItems ];
            ColorConsole.WriteLine( $"------------ {outputMessage [ MessageEnum.MainMenu_ReportsAndSummary ]} ------------", MenuHeadings );
            ColorConsole.WriteLine( "\t1 - " + outputMessage [ MessageEnum.ReportAndSum_TotalIncome ], MenuItemColor, ResetColorAfter: false );
            ColorConsole.WriteLine( "\t2 - " + outputMessage [ MessageEnum.ReportAndSum_TotalExpense ] );
            ColorConsole.WriteLine( "\t3 - " + outputMessage [ MessageEnum.BudgetTools_CurrentBalance ] );
            ColorConsole.WriteLine( "\t4 - " + outputMessage [ MessageEnum.ReportAndSum_MonthlySummary ] );
            ColorConsole.WriteLine( "\t5 - " + outputMessage [ MessageEnum.ReportAndSum_HighestExpenseCategory ] );
            ColorConsole.WriteLine( "\t6 - " + outputMessage [ MessageEnum.Menu_Return ] );
            ColorConsole.Write( $"{outputMessage [ MessageEnum.labelEnter ]} 1, 2, 3, 4, 5, {outputMessage [ MessageEnum.labelOr ]} 6 : ", ConsoleColor.White );
            //will leave color as is next command in flow should reset the color to desired
            string return_str = ColorConsole.ReadLine( ConsoleColor.Yellow );
            return return_str;
        }
        public static void EnterToContinue( bool ClearAfter = false ) {
            Console.WriteLine( outputMessage [ MessageEnum.PressAnyKeyToContinue ] );
            Console.CursorVisible = false;
            Console.ReadKey( true );
            Console.CursorVisible = true;
            if ( ClearAfter ) {
                Console.Clear();
            }
        }
    }
}
